<?php
class borrower_model extends CI_Model
{
    function __construct()
    {
      parent::__construct();
			$this->load->model('maintenance_model');
			$this->load->model('access');
    }

    function getAllUsers()
    {
      $query_string = $this->db->query("SELECT 	DISTINCT UR.EmployeeNumber
      																					, UR.StatusId
                                                , CASE 
                                                    WHEN (SELECT DISTINCT COUNT(Description) 
                                                                          FROM R_Logs 
                                                                          WHERE CreatedBy = UR.EmployeeNumber 
                                                                          AND 
                                                                          (
                                                                            Description = 'Logged in.'
                                                                            OR
                                                                            Description = 'Changed password'
                                                                          )
                                                          ) < 1
                                                    THEN CAST(Password AS CHAR(10000) CHARACTER SET utf8)
                                                    ELSE 'N/A'
                                                END as Password2
                                                , CAST(Password AS CHAR(10000) CHARACTER SET utf8) as Password
      																					, UR.UserRoleId
      																					, R.Description
                                                , DATE_FORMAT(UR.DateCreated, '%d %b %Y %r') as DateCreated
                                                , DATE_FORMAT(UR.DateUpdated, '%d %b %Y %r') as DateUpdated
      																					FROM R_UserRole UR
      																						INNER JOIN R_Role R
      																							ON R.RoleId = UR.RoleId
                                                      AND UR.EmployeeNumber != 'sysad'
			");
      $data = $query_string->result_array();
      return $data;
    }

    function countBorrower($input)
    {
      // get contact number id from contact numbers
      $data1 = $this->db->query("SELECT   ContactNumberId
                                          FROM r_contactnumbers
                                            WHERE ContactNumber = '".$input['FirstName']."'
                                            AND Type = '".$input['MiddleName']."'

      ");

      $detail = $data1->row_array();
      // match contact
      $data2 = $this->db->query("SELECT   *
                                         FROM BORROWER_HAS_CONTACTNUMBER
                                          WHERE ContactNumberId = ".$detail['ContactNumberId']."
                                          AND BorrowerId = ".borrewerId."

      ");
      $data2 = $data2->num_rows();
      return $data2;
    }

    function countContact($input)
    {
      $query_string = $this->db->query("SELECT  * 
                                                FROM r_contactnumbers
                                                  WHERE ContactNumberId = '".$input['FirstName']."'
                                                  AND MiddleName = '".$input['MiddleName']."'
                                                  AND ExtName = '".$input['ExtName']."'
                                                  AND LastName = '".$input['LastName']."'
                                                  AND DateOfBirth = '".$input['DOB']."'

      ");
      $data = $query_string->num_rows();
      return $data;
    }

    function getBorrowerDetail($BorrowerId)
    {
      $query_string = $this->db->query("SELECT  CONCAT(LastName, ', ', FirstName, ' ', MiddleName, ', ', ExtName) as Name
                                                FROM R_Borrowers
                                                  WHERE BorrowerId = '".$BorrowerId."'

      ");
      $data = $query_string->row_array();
      return $data;
    }

    function getBorrowerDetails($Id)
    {
      $query_string = $this->db->query("SELECT DISTINCT B.BorrowerId
                                                , S.name as Salutation
                                                , B.FirstName
                                                , acronym (B.MiddleName) as MiddleInitial
                                                , B.LastName
                                                , B.ExtName
                                                , B.Dependents
                                                , SX.Name as Sex
                                                , N.Description as Nationality
                                                , C.name as CivilStatus
                                                , DATE_FORMAT(B.DateOfBirth, '%d %b %Y') as DateOfBirth
                                                , SS.Description as StatusDescription
                                                , B.StatusId
                                                FROM R_Borrowers B
                                                  INNER JOIN R_Salutation S
                                                    ON S.SalutationId = B.Salutation
                                                  INNER JOIN R_Sex SX
                                                    ON SX.SexId = B.Sex
                                                  INNER JOIN r_nationality N
                                                    ON N.NationalityId = B.Nationality
                                                  INNER JOIN r_civilstatus C
                                                    ON C.CivilStatusId = B.CivilStatus
                                                  INNER JOIN R_Status SS
                                                    ON SS.StatusId = B.StatusId
                                                  WHERE B.BorrowerId = $Id

      ");
      $data = $query_string->row_array();
      return $data;
    }

    function getAllList()
    {
      $query_string = $this->db->query("SELECT DISTINCT B.FirstName
                                                , acronym (B.MiddleName) as MI
                                                , B.LastName
                                                , B.ExtName
                                                , B.StatusId
                                                , S.Description as StatusDescription
                                                , B.Dependents
                                                , DATE_FORMAT(B.DateCreated, '%d %b %Y %h:%i %p') as DateCreated
                                                , DATE_FORMAT(B.DateUpdated, '%d %b %Y %h:%i %p') as DateUpdated
                                                , B.BorrowerId
                                                , CONCAT(B.LastName, ', ', B.FirstName) as Name 
                                                FROM r_Borrowers B
                                                      INNER JOIN r_status S
                                                          ON S.StatusId = B.StatusId
                                                        INNER JOIN r_employee EMP
                                                          ON EMP.EmployeeNumber = B.CreatedBy
                                                        LEFT JOIN R_UserRole R
                                                          ON R.EmployeeNumber = EMP.EmployeeNumber
                                                              WHERE EMP.StatusId = 1
      ");
      $data = $query_string->result_array();
      return $data;
    }

    function getTotalLoans($BorrowerId)
    {      
      $query = $this->db->query("SELECT   COUNT(A.ApplicationId) as Record
                                          FROM t_application A
                                                WHERE A.StatusId = 2
                                                AND A.BorrowerId = $BorrowerId
      ");
      $data = $query->row_array();
      return $data['Record'];
    }


}