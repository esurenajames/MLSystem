<?php
class employee_model extends CI_Model
{
    function __construct()
    {
      parent::__construct();
			$this->load->model('maintenance_model');
			$this->load->model('access');
    }

    function updateStatus($input)
    {
      $EmployeeNumber = $this->session->userdata('EmployeeNumber');
      $DateNow = date("Y-m-d H:i:s");
      // update employee role
        $auditquery = $this->db->query("SELECT  CONCAT(FirstName, ' ', MiddleName, ' ', LastName, CASE WHEN ExtName != '' THEN CONCAT(', ', ExtName) ELSE '' END ) as Name
                                                , LOWER(R.Description) as Description
                                                , EMP.EmployeeNumber
                                                FROM r_userrole UR
                                                  INNER JOIN r_employee EMP
                                                    ON EMP.EmployeeNumber = UR.EmployeeNumber
                                                  INNER JOIN R_role R
                                                    ON R.RoleId = UR.RoleId
                                                      WHERE UR.UserRoleId = ".$input['UserRoleId']."
                                                      LIMIT 1
        ");

        $data = $auditquery->row_array();
        if($input['updateType'] == 1 || $input['updateType'] == 2)
        {
          if($input['updateType'] == 1) // deactivate employee user role
          {
            $StatusId = 2; 
            $auditDetail = 'Deactivated '.$data['Description'].' role for '. $data['Name'];
          }
          if($input['updateType'] == 2) // re-activate employee user role
          {
            $StatusId = 1; 
            $auditDetail = 'Re-activated '.$data['Description'].' role for '. $data['Name'];
          }

          $data1 = array(
            'StatusId' => $StatusId,
            'UpdatedBy' => $EmployeeNumber,
            'DateUpdated' => $DateNow,
            'IsNew' => 1
          );

          $this->db->where('UserRoleId', $input['UserRoleId']);
          $this->db->update('R_UserRole', $data1);

          // insert into logs
            $data2 = array(
              'Description' => $auditDetail,
              'CreatedBy' => $EmployeeNumber,
              'DateCreated' => $DateNow
            );

            $this->db->insert('R_Logs', $data2);
        }
        else // reset password
        {
          $set = array( 
            'Password' => $data['EmployeeNumber']
            , 'IsNew' => 1
          );

          $condition = array( 
            'EmployeeNumber' => $data['EmployeeNumber']
          );
          $table = 'R_UserRole';
          $this->maintenance_model->updateFunction1($set, $condition, $table);
        }
    }

    function countEmployee($input)
    {
      $query_string = $this->db->query("SELECT  * 
                                                FROM r_Employee
                                                  WHERE FirstName = '".$input['FirstName']."'
                                                  AND MiddleName = '".$input['MiddleName']."'
                                                  AND ExtName = '".$input['ExtName']."'
                                                  AND LastName = '".$input['LastName']."'
                                                  AND DateOfBirth = '".$input['DateOfBirth']."'

      ");
      $data = $query_string->num_rows();
      return $data;
    }

    function countContactNumber($input)
    {
      $query_string = $this->db->query("SELECT  DISTINCT ContactNumberId
                                                FROM R_ContactNumbers
                                                  WHERE PhoneType = '".$input['PhoneType']."'
                                                  AND Number = '".$input['Number']."'

      ");
      $data = $query_string->row_array();
      if($data['ContactNumberId'] != null)
      {
        $query2 = $this->db->query("SELECT  *
                                            FROM employee_has_contactnumbers
                                              WHERE ContactNumberId = ".$data['ContactNumberId']."
                                              AND EmployeeNumber = '".$input['EmployeeNumber']."'
        ");
        $data2 = $query2->num_rows();
        return $data2;
      }
      else
      {
        return 0;
      }
    }

    function countEmailAddress($input)
    {
      $query_string = $this->db->query("SELECT  EmailId
                                                FROM r_emails
                                                WHERE EmailAddress = '".$input['EmailAddress']."'

      ");
      $data = $query_string->row_array();
      if($data['EmailId'] != null)
      {
        $query2 = $this->db->query("SELECT  *
                                            FROM employee_has_emails
                                              WHERE EmailId = ".$data['EmailId']."
                                              AND EmployeeNumber = '".$input['EmployeeNumber']."'
        ");
        $data2 = $query2->num_rows();
        return $data2;
      }
      else
      {
        return 0;
      }
    }

    function countAddress($input)
    {
      $query_string = $this->db->query("SELECT  AddressId
                                                FROM r_address
                                                WHERE HouseNo = '".$input['HouseNo']."'
                                                AND Street = '".$input['StreetNo']."'
                                                AND AddressType = '".$input['AddressType']."'
                                                AND BarangayId = '".$input['BarangayId']."'

      ");
      $data = $query_string->row_array();
      if($data['AddressId'] != null)
      {
        $query2 = $this->db->query("SELECT  *
                                            FROM employee_has_address
                                              WHERE AddressId = ".$data['AddressId']."
                                              AND EmployeeNumber = '".$input['EmployeeNumber']."'
        ");
        $data2 = $query2->num_rows();
        return $data2;
      }
      else
      {
        return 0;
      }
    }

    function getSecurityQuestions()
    {
      $query_string = $this->db->query("SELECT SecurityQuestionId
                                              , Name
                                                FROM R_SecurityQuestions
                                                  WHERE StatusId = 1
      ");
      $data = $query_string->result_array();
      return $data;
    }

    function getEmployeeDetail($EmployeeId)
    {
      $query_string = $this->db->query("SELECT  CONCAT(LastName, ', ', FirstName, ' ', MiddleName, ', ', ExtName) as Name
                                                FROM r_Employee
                                                  WHERE EmployeeId = '".$EmployeeId."'

      ");
      $data = $query_string->row_array();
      return $data;
    }

    function checkExisitingEmployee($EmployeeNumber)
    {
      $query = $this->db->query("SELECT  EmployeeNumber
                                                FROM r_Employee
                                                  WHERE EmployeeNumber = '$EmployeeNumber'
                                                  AND StatusId = 2 
      ");
      
      $data = $query->num_rows();
      return $data;
    }

    function checkSecurity($Question, $Answer, $QuestionNumber)
    {
      $query = $this->db->query("SELECT *
                                        FROM r_userrole_has_r_securityquestions
                                          WHERE SecurityQuestionId = $Question
                                          AND Answer = '".htmlentities($Answer, ENT_QUOTES)."'
                                          AND QuestionNumber = $QuestionNumber
                                          AND StatusId = 1
      ");
      
      
      $data = $query->num_rows();
      return $data;
    }

    function getEmployeeDetails($Id)
    {
      $query_string = $this->db->query("SELECT DISTINCT EMP.EmployeeId
                                                , EMP.EmployeeNumber
                                                , S.name as Salutation
                                                , EMP.FirstName
                                                , acronym(EMP.MiddleName) as MiddleInitial
                                                , EMP.LastName
                                                , EMP.ExtName
                                                , SX.Name as Sex
                                                , N.Description as Nationality
                                                , C.name as CivilStatus
                                                , DATE_FORMAT(EMP.DateOfBirth, '%d %b %Y') as DateOfBirth
                                                , DATE_FORMAT(EMP.DateHired, '%d %b %Y') as DateHired
                                                , SS.Description as StatusDescription
                                                , EMP.StatusId
                                                FROM r_Employee EMP
                                                  INNER JOIN R_Salutation S
                                                    ON S.SalutationId = EMP.Salutation
                                                  INNER JOIN R_Sex SX
                                                    ON SX.SexId = EMP.Sex
                                                  INNER JOIN r_nationality N
                                                    ON N.NationalityId = EMP.Nationality
                                                  INNER JOIN r_civilstatus C
                                                    ON C.CivilStatusId = EMP.CivilStatus
                                                  INNER JOIN R_Status SS
                                                    ON SS.StatusId = EMP.StatusId
                                                  WHERE EMP.EmployeeId = $Id

      ");
      $data = $query_string->row_array();
      return $data;
    }

    function getEmployeeBranchDetails($Id)
    {
      $query_string = $this->db->query("SELECT  B.Code
                                                , B.Name
                                                , B.Description
                                                , MEMP.FirstName
                                                , MEMP.LastName
                                                , acronym(MEMP.MiddleName) as MiddleInitial
                                                FROM branch_has_employee BE
                                                  INNER JOIN r_employee EMP
                                                    ON BE.EmployeeNumber = EMP.EmployeeNumber
                                                  LEFT JOIN branch_has_manager BM
                                                    ON BM.ManagerBranchId = BE.ManagerBranchId
                                                  LEFT JOIN r_employee MEMP
                                                    ON MEMP.EmployeeNumber = BM.EmployeeNumber
                                                  INNER JOIN r_branch B
                                                    ON B.BranchId = BM.BranchId
                                                        WHERE EMP.EmployeeId = $Id

      ");
      $data = $query_string->row_array();
      return $data;
    }

    function getBranchManagerDetails($Id)
    {
      $query_string = $this->db->query("SELECT  B.Code
                                                , B.Name
                                                , B.Description
                                                , MEMP.FirstName
                                                , MEMP.LastName
                                                , acronym(MEMP.MiddleName) as MiddleInitial
                                                FROM r_branch B
                                                      LEFT JOIN branch_has_manager BM
                                                        ON BM.BranchId = B.BranchId
                                                      LEFT JOIN r_employee MEMP
                                                        ON MEMP.EmployeeNumber = BM.EmployeeNumber
                                                          WHERE MEMP.EmployeeId = $Id
                                                          AND BM.StatusId = 1

      ");
      $data = $query_string->row_array();
      return $data;
    }

    function getAddress($Id)
    {
      $EmployeeNumber = $this->db->query("SELECT LPAD(".$Id.", 6, 0) as EmployeeNumber")->row_array();
      // $query_string = $this->db->query("SELECT  DISTINCT A.HouseNo
      //                                           , A.Street
      //                                           , A.AddressType
      //                                           , AB.brgyDesc
      //                                           , AC.citymunDesc
      //                                           , AP.provDesc
      //                                           , AR.regDesc
      //                                           FROM R_Address A
      //                                             INNER JOIN employee_has_address EA
      //                                               ON EA.AddressId = A.AddressId
      //                                             INNER JOIN Add_Barangay AB
      //                                               ON AB.BrgyCode = A.BarangayId
      //                                             INNER JOIN Add_Province AP
      //                                               ON AP.ProvCode = AB.ProvCode
      //                                             INNER JOIN Add_City AC
      //                                               ON AC.CityMunCode = AB.CityMunCode
      //                                             INNER JOIN Add_Region AR
      //                                               ON AR.RegCode = AB.RegCode
      //                                                 WHERE EA.EmployeeNumber = '".$EmployeeNumber['EmployeeNumber']."'

      // ");
      $data = $query_string->result_array();
      return $data;
    }

    function getEmployeeProfile($Id)
    {
      $query_string = $this->db->query("SELECT DISTINCT EMP.EmployeeId
                                                , EMP.EmployeeNumber
                                                , S.name as Salutation
                                                , CONCAT(LastName, ', ', FirstName) as Name
                                                , EMP.FirstName
                                                , acronym(EMP.MiddleName) as MiddleInitial
                                                , EMP.LastName
                                                , EMP.ExtName
                                                , SX.Name as Sex
                                                , N.Description as Nationality
                                                , C.name as CivilStatus
                                                , DATE_FORMAT(EMP.DateOfBirth, '%d %b %Y') as DateOfBirth
                                                , DATE_FORMAT(EMP.DateHired, '%d %b %Y') as DateHired
                                                , SS.Description as StatusDescription
                                                , EMP.StatusId
                                                , P.Description as Position
                                                FROM r_Employee EMP
                                                  INNER JOIN R_Salutation S
                                                    ON S.SalutationId = EMP.Salutation
                                                  INNER JOIN R_Sex SX
                                                    ON SX.SexId = EMP.Sex
                                                  INNER JOIN r_nationality N
                                                    ON N.NationalityId = EMP.Nationality
                                                  INNER JOIN r_civilstatus C
                                                    ON C.CivilStatusId = EMP.CivilStatus
                                                  INNER JOIN R_Status SS
                                                    ON SS.StatusId = EMP.StatusId
                                                  INNER JOIN R_Position P
                                                    ON P.PositionId = EMP.PositionId
                                                  WHERE EMP.EmployeeNumber = '$Id'

      ");
      $data = $query_string->row_array();
      return $data;
    }

    function getEmployeeProfileBranchDetails($Id)
    {
      $query_string = $this->db->query("SELECT  B.Code
                                                , B.Name
                                                , B.Description
                                                , MEMP.FirstName
                                                , MEMP.LastName
                                                , acronym(MEMP.MiddleName) as MiddleInitial
                                                FROM branch_has_employee BE
                                                  INNER JOIN r_employee EMP
                                                    ON BE.EmployeeNumber = EMP.EmployeeNumber
                                                  LEFT JOIN branch_has_manager BM
                                                    ON BM.ManagerBranchId = BE.ManagerBranchId
                                                  LEFT JOIN r_employee MEMP
                                                    ON MEMP.EmployeeNumber = BM.EmployeeNumber
                                                  INNER JOIN r_branch B
                                                    ON B.BranchId = BM.BranchId
                                                        WHERE EMP.EmployeeNumber = '$Id'
      ");
      $data = $query_string->row_array();
      return $data;
    }

    function getAllList()
    {
      $Roles = $this->maintenance_model->getLoggedInRoles(); // to check if may access syang maview
      $query_string = $this->db->query("SELECT DISTINCT EMP.EmployeeId
                                                , EMP.EmployeeNumber
                                                , S.name as Salutation
                                                , EMP.FirstName
                                                , acronym(EMP.MiddleName) as MI
                                                , EMP.LastName
                                                , EMP.ExtName
                                                , SX.Name as Sex
                                                , N.Description as Nationality
                                                , C.name as CivilStatus
                                                , EMP.DateOfBirth
                                                , EMP.DateHired
                                                , SS.Description as StatusDescription
                                                , DATE_FORMAT(EMP.DateHired, '%d %b %Y') as DateHired
                                                , DATE_FORMAT(EMP.DateCreated, '%d %b %Y %h:%i %p') as DateCreated
                                                , DATE_FORMAT(EMP.DateCreated, '%d %b %Y %h:%i %p') as DateUpdated
                                                , EMP.StatusId
                                                , EMP.CreatedBy
                                                , B.Name as Branch
                                                FROM r_Employee EMP
                                                  INNER JOIN R_Salutation S
                                                    ON S.SalutationId = EMP.Salutation
                                                  INNER JOIN R_Sex SX
                                                    ON SX.SexId = EMP.Sex
                                                  INNER JOIN r_nationality N
                                                    ON N.NationalityId = EMP.Nationality
                                                  INNER JOIN r_civilstatus C
                                                    ON C.CivilStatusId = EMP.CivilStatus
                                                  INNER JOIN R_Status SS
                                                    ON SS.StatusId = EMP.StatusId
                                                  INNER JOIN Branch_has_Employee BE
                                                    ON BE.EmployeeNumber = EMP.EmployeeNumber
                                                  INNER JOIN R_Branch B
                                                    ON B.BranchId = BE.BranchId
                                                      ORDER BY EMP.LastName ASC
      ");
      $data = $query_string->result_array();
      return $data;
    }

    function getCurrentPassword($Password ,$EmployeeNumber)
    {
      $Roles = $this->maintenance_model->getLoggedInRoles(); // to check if may access syang maview
      $query_string = $this->db->query("SELECT Password
                                                FROM R_UserRole
                                                  WHERE EmployeeNumber = '$EmployeeNumber'
                                                  AND Password = '$Password'
      ");
      $data = $query_string->num_rows();
      return $data;
    }

    function managerNotifications($EmployeeNumber)
    {
      $query_string = $this->db->query("SELECT  MN.Description
                                                , MN.CreatedBy
                                                , DATE_FORMAT(MN.DateCreated, '%d %b %Y %h:%i %p') as DateCreated
                                                , DATE_FORMAT(MN.DateCreated, '%d %b %Y %h:%i %p') as rawDateCreated
                                                , MN.NotificationId
                                                FROM Manager_has_Notifications MN
                                                  INNER JOIN branch_has_manager BM
                                                    ON BM.ManagerBranchId = MN.ManagerBranchId
                                                  INNER JOIN R_Employee EMP
                                                    ON EMP.EmployeeNumber = BM.EmployeeNumber
                                                      WHERE EMP.EmployeeNumber = '$EmployeeNumber' 
      ");
      $data = $query_string->result_array();
      return $data;
    }

    function employeeAudit($EmployeeNumber)
    {
      $query_string = $this->db->query("SELECT  Description
                                                , DATE_FORMAT(DateCreated, '%d %b %Y %h:%i %p') as DateCreated
                                                , DATE_FORMAT(DateCreated, '%d %b %Y %h:%i %p') as rawDateCreated
                                                , CreatedBy
                                                , EmployeeLogId
                                                FROM l_employeelog 
                                                  WHERE CreatedBy = '$EmployeeNumber' 
      ");
      $data = $query_string->result_array();
      return $data;
    }

    function contactNumbers($EmployeeNumber)
    {
      $EmployeeNumber = $this->db->query("SELECT LPAD($EmployeeNumber, 6, 0) as EmployeeNumber")->row_array();
      $query_string = $this->db->query("SELECT  CN.PhoneType
                                                , Number
                                                , EC.StatusId
                                                , EC.CreatedBy
                                                , EC.EmployeeContactId
                                                , EC.IsPrimary
                                                , DATE_FORMAT(EC.DateCreated, '%d %b %Y %h:%i %p') as DateCreated
                                                , DATE_FORMAT(EC.DateUpdated, '%d %b %Y %h:%i %p') as DateUpdated
                                                FROM R_ContactNumbers CN
                                                  INNER JOIN Employee_has_contactNumbers EC
                                                    ON EC.ContactNumberId = CN.ContactNumberId
                                                      WHERE EC.EmployeeNumber = ".$EmployeeNumber['EmployeeNumber']."
      ");
      $data = $query_string->result_array();
      return $data;
    }

    function employeeEmails($EmployeeNumber)
    {
      $EmployeeNumber = $this->db->query("SELECT LPAD($EmployeeNumber, 6, 0) as EmployeeNumber")->row_array();
      $query_string = $this->db->query("SELECT  E.EmailAddress
                                                , EE.StatusId
                                                , EE.EmployeeEmailId
                                                , EE.IsPrimary
                                                , EE.CreatedBy
                                                , DATE_FORMAT(EE.DateCreated, '%d %b %Y %h:%i %p') as DateCreated
                                                , DATE_FORMAT(EE.DateUpdated, '%d %b %Y %h:%i %p') as DateUpdated
                                                FROM R_Emails E
                                                  INNER JOIN employee_has_emails EE
                                                    ON EE.EmailId = E.EmailId
                                                      WHERE EE.EmployeeNumber = ".$EmployeeNumber['EmployeeNumber']."
      ");
      $data = $query_string->result_array();
      return $data;
    }

    function updateContactNumber($input)
    {
      $EmployeeNumber = $this->session->userdata('EmployeeNumber');
      $DateNow = date("Y-m-d H:i:s");
      $EmployeeDetail = $this->db->query("SELECT  EC.EmployeeNumber 
                                                  , C.Number
                                                  FROM employee_has_contactnumbers EC
                                                    INNER JOIN R_ContactNumbers C
                                                      ON EC.ContactNumberId = C.ContactNumberId
                                                    WHERE EC.EmployeeContactId = ".$input['Id']."
      ")->row_array();

      if($input['updateType'] == 1 || $input['updateType'] == 0) // deactivate and re-activate email of employee
      {
        // update status
          $set = array( 
            'StatusId' => $input['updateType'],
            'UpdatedBy' => $EmployeeNumber,
            'DateUpdated' => $DateNow,
          );

          $condition = array( 
            'EmployeeContactId' => $input['Id']
          );
          $table = 'employee_has_contactnumbers';
          $this->maintenance_model->updateFunction1($set, $condition, $table);
        // insert into logs
          if($input['updateType'] == 1)
          {
            $Description = 'Re-activated ' .$EmployeeDetail['Number']. ' contact number of employee #'.$EmployeeDetail['EmployeeNumber']; // main log
            $EmployeeNotification = 'Re-activated ' .$EmployeeDetail['Number']. ' as contact number.'; // employee notification
          }
          else if($input['updateType'] == 0)
          {
            $Description = 'Deactivated ' .$EmployeeDetail['Number']. '  contact number record of employee #'.$EmployeeDetail['EmployeeNumber']; // main log
            $EmployeeNotification = 'Deactivated ' .$EmployeeDetail['Number']. ' as contact number.'; // employee notification
          }
          $data2 = array(
            'Description'   => $Description,
            'CreatedBy'     => $EmployeeNumber,
            'DateCreated'   => $DateNow
          );
          $this->db->insert('R_Logs', $data2);
          $data3 = array(
            'Description'   => $EmployeeNotification,
            'CreatedBy'     => $EmployeeNumber,
            'DateCreated'   => $DateNow
          );
          $this->db->insert('employee_has_notifications', $data3);
      }
    }

    function updateEmail($input)
    {
      $EmployeeNumber = $this->session->userdata('EmployeeNumber');
      $DateNow = date("Y-m-d H:i:s");
      $EmployeeDetail = $this->db->query("SELECT  EE.EmployeeNumber 
                                                  , E.EmailAddress
                                                  FROM employee_has_emails EE
                                                    INNER JOIN R_Emails E
                                                      ON E.EmailId = EE.EmailId
                                                    WHERE EE.EmployeeEmailId = ".$input['Id']."
      ")->row_array();
      if($input['updateType'] == 1 || $input['updateType'] == 0) // deactivate and re-activate email of employee
      {
        // update status
          $set = array( 
            'StatusId' => $input['updateType'],
            'UpdatedBy' => $EmployeeNumber,
            'DateUpdated' => $DateNow,
          );
          $condition = array( 
            'EmployeeEmailId' => $input['Id']
          );
          $table = 'employee_has_emails';
          $this->maintenance_model->updateFunction1($set, $condition, $table);
        // insert into logs
          if($input['updateType'] == 1)
          {
            $Description = 'Re-activated ' .$EmployeeDetail['EmailAddress']. ' email record of employee #'.$EmployeeDetail['EmployeeNumber']; // main log
            $EmployeeNotification = 'Re-activated ' .$EmployeeDetail['EmailAddress']. ' as email address.'; // employee notification
          }
          else if($input['updateType'] == 0)
          {
            $Description = 'Deactivated ' .$EmployeeDetail['EmailAddress']. '  email record of employee #'.$EmployeeDetail['EmployeeNumber']; // main log
            $EmployeeNotification = 'Deactivated ' .$EmployeeDetail['EmailAddress']. ' as email address.'; // employee notification
          }
          $data2 = array(
            'Description'   => $Description,
            'CreatedBy'     => $EmployeeNumber,
            'DateCreated'   => $DateNow
          );
          $this->db->insert('R_Logs', $data2);
          $data3 = array(
            'Description'   => $EmployeeNotification,
            'CreatedBy'     => $EmployeeNumber,
            'DateCreated'   => $DateNow
          );
          $this->db->insert('employee_has_notifications', $data3);
      }
      else // set as primary email
      {
        // update primary to not primary status
          $set = array( 
            'IsPrimary' => 0,
            'UpdatedBy' => $EmployeeNumber,
            'DateUpdated' => $DateNow,
          );
          $condition = array( 
            'EmployeeNumber' => $EmployeeDetail['EmployeeNumber'],
            'IsPrimary' => 1
          );
          $table = 'employee_has_emails';
          $this->maintenance_model->updateFunction1($set, $condition, $table);
        // update status
          $set = array( 
            'IsPrimary' => 1,
            'UpdatedBy' => $EmployeeNumber,
            'DateUpdated' => $DateNow,
          );
          $condition = array( 
            'EmployeeEmailId' => $input['Id']
          );
          $table = 'employee_has_emails';
          $this->maintenance_model->updateFunction1($set, $condition, $table);
        // insert into logs
          $Description = 'Set ' .$EmployeeDetail['EmailAddress']. ' of employee #'.$EmployeeDetail['EmployeeNumber'] . ' as primary.'; // main log
          $EmployeeNotification = 'Set ' .$EmployeeDetail['EmailAddress']. ' as primary email address.'; // employee notification
      }
    }

}