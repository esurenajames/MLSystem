
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Employee Details for <?php print_r($detail['LastName'] . ', ' . $detail['FirstName']) ?>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#" class="active"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li><a href="#">Employee Details</a></li>
    </ol>
  </section>
  <div class="modal fade" id="modalNewContact">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Employee Details</h4>
        </div>
        <form autocomplete="off" action="<?php echo base_url(); ?>employee_controller/employeeProcessing/2/<?php print_r($detail['EmployeeNumber'])?>" id="frmInsert2" method="post">
          <div class="modal-body">
            <div class="row">
              <div class="col-md-12">
                <div class="radio">
                  <label>
                    <input type="radio" name="ContactType" id="optionsRadios1" value="Mobile" checked="">
                    Mobile
                  </label>
                  <label>
                    <input type="radio" name="ContactType" id="optionsRadios2" value="Telephone">
                    Telephone
                  </label>
                </div>
              </div>
              <input type="hidden" required="" class="form-control" value="<?php print_r($detail['EmployeeId']) ?>" name="EmployeeId">
              <div class="col-md-12">
                <label>Number</label>
                <div class="input-group">
                  <span class="input-group-addon">
                    <input type="checkbox" name="isPrimary[]" value="1" title="Primary Number?">
                  </span>
                  <input type="text" name="FieldNumber" required="" class="form-control">
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <div class="modal fade" id="modalNewEmail">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Email Details</h4>
        </div>
        <form autocomplete="off" action="<?php echo base_url(); ?>employee_controller/employeeProcessing/3/<?php print_r($detail['EmployeeNumber'])?>" id="frmInsert2" method="post">
          <div class="modal-body">
            <div class="row">
              <input type="hidden" required="" class="form-control" value="<?php print_r($detail['EmployeeId']) ?>" name="EmployeeId">
              <div class="col-md-12">
                <label>Email Address</label>
                <div class="input-group">
                  <span class="input-group-addon">
                    <input type="checkbox" name="isPrimary[]" value="1" title="Primary Email Address?">
                  </span>
                  <input type="text" name="EmailAddress" required="" class="form-control">
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <div class="modal fade" id="modalNewAddress">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Address</h4>
        </div>
        <form autocomplete="off" action="<?php echo base_url(); ?>employee_controller/employeeProcessing/4/<?php print_r($detail['EmployeeNumber'])?>" id="frmInsert2" method="post">
          <div class="modal-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="select">Address Type <span class="text-red">*</span></label>
                  <select class="form-control select2"  required="" id="selectAddressType" name="AddressType" style="width: 100%">
                    <option value="City Address">City Address</option>
                    <option value="Province Address">Provincial Address</option>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label>Primary Address? <span class="text-red">*</span></label>
                  <select class="form-control select2"  required="" name="isPrimary" style="width: 100%">
                    <option value="1">Yes</option>
                    <option value="0">No</option>
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="txtHouseNo">House No. <span class="text-red">*</span></label>
                  <input type="text" class="form-control" id="txtHouseNo" name="HouseNo" required="" placeholder="House No.">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="txtStreet">Street <span class="text-red">*</span></label>
                  <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="" placeholder="Street">
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="selectRegion">Region <span class="text-red">*</span></label>
                  <select class="form-control select2"  required="" onchange="changeRegion(this.value)" id="selectRegion" name="RegionId" style="width: 100%">
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="selectRegion">Province <span class="text-red">*</span></label>
                  <select class="form-control select2"  required="" id="selectProvince" onchange="changeProvince(this.value)" name="ProvinceId" style="width: 100%">
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="selectCity">City <span class="text-red">*</span></label>
                  <select class="form-control select2" required="" id="selectCity" onchange="changeCity(this.value)" name="CityId" style="width: 100%">
                  </select>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="selectBarangay">Barangay <span class="text-red">*</span></label>
                  <select class="form-control select2" required="" id="selectBarangay" name="BarangayId" style="width: 100%">
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>
  <!-- Main content -->
  <section class="content">    
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">Personal Information</h3>
        <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewRecord">Edit Employee</button>
      </div>
      <div class="box-body">
        <div class="row">
          <div class="col-md-3">
            <label>Employee Number</label>
            <h6><?php print_r($detail['EmployeeNumber']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Salutation</label>
            <h6><?php print_r($detail['Salutation']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Full Name</label>
            <h6><?php print_r($detail['LastName'] . ', ' . $detail['FirstName'] . ' '  . $detail['MiddleInitial']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Sex</label>
            <h6><?php print_r($detail['Sex']) ?></h6>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3">
            <label>Civil Status</label>
            <h6><?php print_r($detail['CivilStatus']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Date of Birth</label>
            <h6><?php print_r($detail['DateOfBirth']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Date Hired</label>
            <h6><?php print_r($detail['DateHired']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Status</label>
            <h6><?php print_r($detail['StatusDescription'])?></h6>
          </div>
        </div>
      </div>
    </div>

    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">Branch Information</h3>
      </div>
      <div class="box-body">
        <div class="nav-tabs-custom">
          <ul class="nav nav-tabs">
            <li class="active"><a href="#BranchDetails" data-toggle="tab">Branch Details</a></li>
            <li><a href="#ContactDetails" data-toggle="tab">Contact Details</a></li>
            <li><a href="#EmailDetails" data-toggle="tab">Email Address</a></li>
            <li><a href="#AddressDetails" data-toggle="tab">Address</a></li>
            <li><a href="#IdDetails" data-toggle="tab">IDs</a></li>
          </ul>
          <div class="tab-content">
            <div class="active tab-pane" id="BranchDetails">
              <?php if($branchManager['Code'] != '') { ?>
                <?php $this->load->view('employees/branchmanager'); ?>
              <?php } else { ?>
                <?php $this->load->view('employees/branchemployee'); ?>
              <?php }?>
            </div>
            <div class="tab-pane" id="ContactDetails">
              <br>
              <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewContact">Add Contact Number</button>
              <br>
              <br>
              <?php $this->load->view('employees/contact'); ?>
            </div>
            <div class="tab-pane" id="EmailDetails">
              <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewEmail">Add Email</button>
              <br>
              <br>
              <?php $this->load->view('employees/email'); ?>
            </div>
            <div class="tab-pane" id="AddressDetails">
              <br>
              <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewAddress">Add Address</button>
              <br>
              <br>
              <br>
              <?php $this->load->view('employees/address'); ?>
            </div>
            <div class="tab-pane" id="IdDetails">
              <br>
              <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewId">Add ID</button>
              <br>
              <br>
              <br>
              <?php $this->load->view('employees/address'); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1.0.0
  </div>
  <strong>Copyright &copy; 2020 <a href="https://adminlte.io">GIA Tech.</a>.</strong> All rights
  reserved.
</footer>

<div class="loading" style="display: none">Loading&#8230;</div>
<?php $this->load->view('includes/footer'); ?>

<script>

  function confirm(Text, EmployeeContactId, updateType)
  { 
    swal({
      title: 'Confirm',
      text: Text,
      type: 'info',
      showCancelButton: true,
      buttonsStyling: false,
      confirmButtonClass: 'btn btn-success',
      confirmButtonText: 'Confirm',
      cancelButtonClass: 'btn btn-secondary'
    }).then(function(){
      $.ajax({                
          url: "<?php echo base_url();?>" + "/employee_controller/updateContactNumber",
          method: "POST",
          data:   {
                    EmployeeContactId : EmployeeContactId
                    , updateType : updateType
                  },
          beforeSend: function(){
              $('.loading').show();
          },
          success: function(data)
          {
            refreshContacts();
            swal({
              title: 'Success!',
              text: 'Successfully updated!',
              type: 'success',
              buttonsStyling: false,
              confirmButtonClass: 'btn btn-primary'
            });
          },
          error: function (response) 
          {
            refreshContacts();
            swal({
              title: 'Warning!',
              text: 'Something went wrong, please contact the administrator or refresh page!',
              type: 'warning',
              buttonsStyling: false,
              confirmButtonClass: 'btn btn-primary'
            });
          }
      });
    });
  }

  function confirmEmail(Text, EmployeeEmailId, updateType)
  { 
    swal({
      title: 'Confirm',
      text: Text,
      type: 'info',
      showCancelButton: true,
      buttonsStyling: false,
      confirmButtonClass: 'btn btn-success',
      confirmButtonText: 'Confirm',
      cancelButtonClass: 'btn btn-secondary'
    }).then(function(){
      $.ajax({                
          url: "<?php echo base_url();?>" + "/employee_controller/updateEmail",
          method: "POST",
          data:   {
                    Id : EmployeeEmailId
                    , updateType : updateType
                  },
          beforeSend: function(){
            $('.loading').show();
          },
          success: function(data)
          {
            refreshEmail();
            swal({
              title: 'Success!',
              text: 'Successfully updated!',
              type: 'success',
              buttonsStyling: false,
              confirmButtonClass: 'btn btn-primary'
            });
          },
          error: function (response) 
          {
            refreshEmail();
            swal({
              title: 'Warning!',
              text: 'Something went wrong, please contact the administrator or refresh page!',
              type: 'warning',
              buttonsStyling: false,
              confirmButtonClass: 'btn btn-primary'
            });
          }
      });
    });
  }

  function ChangePassword()
  {
    $('#modalChangePassword').modal('show');
  }

  if("<?php print_r($this->session->flashdata('alertTitle')) ?>" != '')
  {
    swal({
      title: '<?php print_r($this->session->flashdata('alertTitle')) ?>',
      text: '<?php print_r($this->session->flashdata('alertText')) ?>',
      type: '<?php print_r($this->session->flashdata('alertType')) ?>',
      buttonsStyling: false,
      confirmButtonClass: 'btn btn-primary'
    });
  }

  function refreshPage(){
    var url = '<?php echo base_url()."datatables_controller/Users/"; ?>';
    UserTable.ajax.url(url).load();
  }

  function refreshContacts(){
    var url = '<?php echo base_url()."employee_controller/contactNumbers/"; ?>' + <?php print_r($detail['EmployeeId'])?>;
    dtblContactNumber.ajax.url(url).load();
  }

  function refreshEmail(){
    var url = '<?php echo base_url()."employee_controller/employeeEmails/"; ?>' + <?php print_r($detail['EmployeeId'])?>;
    dtblEmailAddress.ajax.url(url).load();
  }

  function checkPasswordMatch(Password)
  {
    var element = document.getElementById("colorSuccess2");
    if($('#txtNewPassword').val() != Password)
    {
      element.classList.remove("has-success");
      element.classList.add("has-error");
      $('#successMessage2').slideDown();
      $('#successMessage2').html('Password does not match');
      varStatus = 0;
    }
    else
    {
      element.classList.remove("has-error");
      element.classList.add("has-success");
      $('#successMessage2').slideDown();
      $('#successMessage2').html('Password matching');
      varStatus = 1;
    }
  }

  function checkNewPassword(Password)
  {
    var element = document.getElementById("colorSuccess2");
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W\_])[A-Za-z\d\W\_]{8,}$/;
    const str = $('#txtNewPassword').val();
    let m;
    if($('#txtConfirmPassword').val() != Password)
    {
      element.classList.remove("has-success");
      element.classList.add("has-error");
      $('#successMessage2').slideDown();
      $('#successMessage2').html('Password does not match');
      varStatus = 0;
    }
    else
    {
      element.classList.remove("has-error");
      element.classList.add("has-success");
      $('#successMessage2').slideDown();
      $('#successMessage2').html('Password matching');
      varStatus = 1;
    }

    if ((m = regex.exec(str)) !== null) {
        // The result can be accessed through the `m`-variable.
        m.forEach((match, groupIndex) => {
          var element = document.getElementById("colorSuccess");
          element.classList.remove("has-error");
          element.classList.add("has-success");
          $('#successMessage').slideDown();
          $('#successMessage').html('Valid Password');
          varNewPassword = 1;
        });
    }
    else
    {
      var element = document.getElementById("colorSuccess");
      element.classList.remove("has-success");
      element.classList.add("has-error");
      $('#successMessage').slideDown();
      $('#successMessage').html('Password must contain a special, numeric and an uppercase character');
      varNewPassword = 0;
    }
  }

  function changeRegion(RegionId)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getProvinces",
      method: "POST",
      data: { RegionId : RegionId },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectProvince').html(data);
      }
    })
  }

  function changeProvince(ProvinceCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getCities",
      method: "POST",
      data: { Id : ProvinceCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectCity').html(data);
      }
    })
  }

  function changeCity(CityCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getBarangays",
      method: "POST",
      data: { Id : CityCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectBarangay').html(data);
      }
    })
  }

  $(function () {

    $("#frmInsert").on('submit', function (e) {
      if(varNewPassword = 1 && varStatus == 1 && $('#txtNewPassword').val() == $('#txtConfirmPassword').val() && $('#txtOldPassword').val() != $('#txtNewPassword').val())
      {
        e.preventDefault(); 
        swal({
          title: 'Confirm',
          text: 'Are you sure you sure with this password?',
          type: 'info',
          showCancelButton: true,
          buttonsStyling: false,
          confirmButtonClass: 'btn btn-success',
          confirmButtonText: 'Confirm',
          cancelButtonClass: 'btn btn-secondary'
        }).then(function(){
          e.currentTarget.submit();
        });
      }
      else
      {
        alert('please make sure your new password is not equal to your old password!')
        e.preventDefault();
      }
    });
    
    $('#selectRoles').select2({
      placeholder: 'Type a role to select',
      dropdownCssClass : 'bigdrop',
        ajax: {
          url: '<?php echo base_url()?>admin_controller/getRoles?>',
          dataType: 'json',
          delay: 250,
          processResults: function (data) 
          {
            return {
              results: data
            };
          },
          cache: true
        }
    });

    $('#selectEmployee').select2({
      placeholder: 'Type an employee name or employee number to select.',
      dropdownCssClass : 'bigdrop',
        ajax: {
          url: '<?php echo base_url()?>admin_controller/getEmployees?>',
          dataType: 'json',
          delay: 250,
          processResults: function (data) 
          {
            return {
              results: data
            };
          },
          cache: true
        }
    });

    // $contactNo = 0;
    // dtblContactNumber = $('#dtblContactNumber').DataTable({
    //   "pageLength": 10,
    //   "ajax": { url: '<?php echo base_url()."/employee_controller/contactNumbers/"; ?>' + <?php print_r($detail['EmployeeId'])?>, type: 'POST', "dataSrc": "" },
    //   "columns": [  {
    //                   data: "EmployeeContactId", "render": function (data, type, row) {
    //                     return $contactNo = $contactNo + 1;
    //                   }
    //                 }
    //                 , { data: "PhoneType" }
    //                 , { data: "Number" }
    //                 , { data: "Name" }
    //                 , { data: "IsPrimary", "render": function (data, type, row) {
    //                     if(row.IsPrimary == 1){
    //                       return "Yes";
    //                     }
    //                     else{
    //                       return "No";
    //                     }
    //                   }
    //                 }
    //                 , { data: "DateCreated" }
    //                 , { data: "DateUpdated" }
    //                 , { data: "StatusId", "render": function (data, type, row) {
    //                     if(row.StatusId == 1){
    //                       return "<span class='badge bg-green'>Active</span>";
    //                     }
    //                     else{
    //                       return "<span class='badge bg-red'>Deactivated</span>";
    //                     }
    //                   }
    //                 }
    //                 , {
    //                   data: "StatusId", "render": function (data, type, row) {
    //                     if(row.StatusId == 1 && row.IsPrimary == 1){
    //                       return '<a onclick="confirm(\'Are you sure you want to deactivate this email?\', \''+row.EmployeeContactId+'\', 0)" class="btn btn-danger btn-sm" title="Deactivate"><span class="fa fa-close"></span></a>';
    //                     }
    //                     else if(row.StatusId == 1 && row.IsPrimary == 0){
    //                       return '<a onclick="confirm(\'Are you sure you want to deactivate this email?\', \''+row.EmployeeContactId+'\', 0)" class="btn btn-danger btn-sm" title="Deactivate"><span class="fa fa-close"></span></a> <a onclick="confirm(\'Are you sure you want to this email your primary email?\', \''+row.EmployeeContactId+'\', 2)" class="btn btn-success btn-sm" title="Make as primary"><span class="fa fa-check-circle"></span></a>';
    //                     }
    //                     else{
    //                       return '<a onclick="confirm(\'Are you sure you want to re-activate this email?\', \''+row.EmployeeContactId+'\', 1)" class="btn btn-warning btn-sm" title="Deactivate"><span class="fa fa-refresh"></span></a>';
    //                     }
    //                   }
    //                 },
    //   ],
    //   // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
    //   "order": [[4, "desc"]]
    // });

    // $emailNo = 0;
    // dtblEmailAddress = $('#dtblEmailAddress').DataTable({
    //   "pageLength": 10,
    //   "ajax": { url: '<?php echo base_url()."/employee_controller/employeeEmails/"; ?>' + <?php print_r($detail['EmployeeId'])?>, type: 'POST', "dataSrc": "" },
    //   "columns": [  {
    //                   data: "EmployeeEmailId", "render": function (data, type, row) {
    //                     return $emailNo = $emailNo + 1;
    //                   }
    //                 }
    //                 , { data: "EmailAddress" }
    //                 , { data: "Name" }
    //                 , { data: "IsPrimary", "render": function (data, type, row) {
    //                     if(row.IsPrimary == 1){
    //                       return "Yes";
    //                     }
    //                     else{
    //                       return "No";
    //                     }
    //                   }
    //                 }
    //                 , { data: "DateCreated" }
    //                 , { data: "DateUpdated" }
    //                 , {
    //                   data: "StatusId", "render": function (data, type, row) {
    //                     if(row.StatusId == 1){
    //                       return "<span class='badge bg-green'>Active</span>";
    //                     }
    //                     else{
    //                       return "<span class='badge bg-red'>Deactivated</span>";
    //                     }
    //                   }
    //                 },
    //                 {
    //                   data: "StatusId", "render": function (data, type, row) {
    //                     if(row.StatusId == 1 && row.IsPrimary == 1){
    //                       return '<a onclick="confirmEmail(\'Are you sure you want to deactivate this email?\', \''+row.EmployeeEmailId+'\', 0)" class="btn btn-danger btn-sm" title="Deactivate"><span class="fa fa-close"></span></a>';
    //                     }
    //                     else if(row.StatusId == 1 && row.IsPrimary == 0){
    //                       return '<a onclick="confirmEmail(\'Are you sure you want to deactivate this email?\', \''+row.EmployeeEmailId+'\', 0)" class="btn btn-danger btn-sm" title="Deactivate"><span class="fa fa-close"></span></a> <a onclick="confirmEmail(\'Are you sure you want to this email your primary email?\', \''+row.EmployeeEmailId+'\', 2)" class="btn btn-success btn-sm" title="Make as primary"><span class="fa fa-check-circle"></span></a>';
    //                     }
    //                     else{
    //                       return '<a onclick="confirmEmail(\'Are you sure you want to re-activate this email?\', \''+row.EmployeeEmailId+'\', 1)" class="btn btn-warning btn-sm" title="Deactivate"><span class="fa fa-refresh"></span></a>';
    //                     }
    //                   }
    //                 },
    //   ],
    //   // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
    //   "order": [[3, "desc"]]
    // });

    $('.select2').select2();

    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getRegionList",
      method: "POST",
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectRegion').html(data);
      }
    })

  })
</script>