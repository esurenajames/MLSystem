
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Loan Calculator
    </h1>
    <ol class="breadcrumb">
      <li><a href="#" class="active"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li><a href="#">Loans</a></li>
      <li><a href="#">Loan Calculator</a></li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">
    <!-- Default box -->
    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title"></h3>
      </div>
      <div class="box-body">
        <form id="loan-form">          
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="exampleInputEmail1">Loan Amount</label>
                <input type="number" class="form-control" id="amount" placeholder="Loan Amount">
              </div>
            </div>
          </div>   
          <div class="row">
            <div class="col-md-12">
              <label for="txtInterest">Interest</label>
              <div class="input-group">
                <span class="input-group-addon">%</span>
                <input type="decimal" id="interest" class="form-control">
              </div>
            </div>
          </div>
          <br>
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="txtDuration">Duration</label>
                <input type="number" class="form-control" id="years" placeholder="Loan Duration">
              </div>
            </div>
          </div>
          <br>
          <div class="row">
            <div class="col-md-10">
            </div>
            <div class="col-md-2">
              <button id="btnCalculate">Calculate</button>
              <button class="btn btn-primary">Print</button>
            </div>
          </div>
        </form>

                
        <div id="loading">
            <img src="img/loading.gif" alt="">
        </div>
        
       <div class="row">
          <div id="results">
            <div class="col-md-4">
              <span class="input-group-text">Monthly Payment</span>
              <input type="number" class="form-control" id="monthly-payment" disabled>
            </div>
            <div class="col-md-4">
              <span class="input-group-text">Total Payment</span>
              <input type="number" class="form-control" id="total-payment" disabled>
            </div>
            <div class="col-md-4">
              <span class="input-group-text">Total Interest</span>
              <input type="number" class="form-control" id="total-interest" disabled>
            </div>
          </div>
       </div>
        <!-- <form id="frmLoanCalculator" name="frmNameLoanCalculator">
          <div class="row">
            <div class="col-md-12">
              <div class="form-group">
                <label for="exampleInputEmail1">Loan Amount<code>*</code> </label>
                <input type="number" class="form-control" id="txtLoanAmount" placeholder="Loan Amount">
              </div>
            </div>
          </div>   
          <div class="row">
            <div class="col-md-3">
              <div class="form-group">
                <label for="selectTerm">Loan Term</label>
                <select name="selectTerm" class="form-control">
                  <option>Weeks</option>
                  <option>Months</option>
                  <option>Years</option>
                </select>
              </div>
            </div>
            <div class="col-md-9">
              <div class="form-group">
                <label for="txtDuration">Duration</label>
                <input type="number" class="form-control" id="txtDuration" placeholder="Loan Duration">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <label for="txtInterest">Interest</label>
              <div class="input-group">
                <span class="input-group-addon">%</span>
                <input type="decimal" id="txtInterest" class="form-control">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="exampleInputEmail1">From<code>*</code> </label>
                <input type="date" class="form-control" id="dtpFrom" placeholder="Loan Amount">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="exampleInputEmail1">To<code>*</code> </label>
                <input type="date" class="form-control" id="dtpTo" placeholder="Loan Amount">
              </div>
            </div>
          </div>   
          <br>
          <div class="row">
            <div class="col-md-10">
            </div>
            <div class="col-md-2">
              <button class="btn btn-primary">Generate</button>
              <button class="btn btn-primary">Print</button>
            </div>
          </div>
        </form> -->
      </div>
    </div>
    <!-- /.box -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1.0.0
  </div>
  <strong>Copyright &copy; 2020 <a href="https://adminlte.io">GIA Tech.</a>.</strong> All rights
  reserved.
</footer>

<div class="loading" style="display: none">Loading&#8230;</div>
<?php $this->load->view('includes/footer'); ?>

<script>

  // function callLoan()
  // {
  //   var totalAmount = 0;

  //   totalAmount = (Number($('#txtLoanAmount').val()) * Number($('#txtInterest').val()) / 100) * Number($('#txtDuration').val() + Number($('#txtLoanAmount').val()))

  //   console.log(totalAmount.toFixed(2))
  // } 

  $('#year').text(new Date().getFullYear());



// Calculate Results
function calculateResults(){
    //UI variable
    const UIamount = document.getElementById('amount');
    const UIinterest = document.getElementById("interest");
    const UIyears = document.getElementById("years");
    const UImonthlyPayment = document.getElementById("monthly-payment");
    const UItotalPayment= document.getElementById("total-payment");
    const UItotalInterest = document.getElementById("total-interest");

    const principal = parseFloat(UIamount.value);
    const calculatedInterest = parseFloat(UIinterest.value)/100 / 12 ;
    const calculatedPayments = parseFloat(UIyears.value)*12;

    //complate monthly payment
    const x = Math.pow(1 + calculatedInterest,calculatedPayments);
    const monthly = (principal*x*calculatedInterest)/(x-1);
    
    if(principal < 0)
    {
        showError('Please Enter Positive Amount for Principal');
    }
    else if(calculatedInterest < 0)
    {
        showError('Please Enter Positive Interest Rate');
    }
    else if(calculatedPayments  < 0)
    {
        showError('Please Enter Positive Value');
    }
    else if(isFinite(monthly)){
        UImonthlyPayment.value = monthly.toFixed(2);
        UItotalPayment.value = (monthly*calculatedPayments).toFixed(2);
        UItotalInterest.value = ((monthly * calculatedPayments)-principal).toFixed(2);
        //show result
        document.getElementById('results').style.display = 'block';
        //hide loader
        document.getElementById('loading').style.display = 'none';
    }else{
        
        showError('Please check your number');
    }


}


//Show Error

function showError(error){
    //hide result
    document.getElementById('results').style.display = 'none';
    //hide loader
    document.getElementById('loading').style.display = 'none';
    //create a div
    const errorDiv =document.createElement('div');

    //get Element
    const card = document.querySelector('.card');
    const heading =document.querySelector('.heading');

    //add class
    errorDiv.className = 'alert alert-danger';

    //  Create text node and append to div
    errorDiv.appendChild(document.createTextNode(error));

    //Insert Error above heading
    card.insertBefore(errorDiv,heading);

    //clear Error after 3second
    setTimeout(clearError,2000);
}

function clearError()
{
    document.querySelector('.alert').remove();
}

  $(function () {

    document.getElementById('loan-form').addEventListener('submit',function (e) {
        //hide results
        document.getElementById('results').style.display = 'none';
        //show result
        document.getElementById('loading').style.display = 'block';
        setTimeout(calculateResults,2000);
        e.preventDefault();
    });

    $('#example1').DataTable()
    $('#example2').DataTable({})
    $('#example3').DataTable({})


    // $('#txtInterest').change(function(){
    //   callLoan();
    // });

    // $('#txtLoanAmount').change(function(){
    //   callLoan();
    // });

    // $('#txtDuration').change(function(){
    //   callLoan();
    // });

    // $('#dtpFrom').change(function(){
    //   var a = Number($('#txtDuration').val());
    //   var CurrentDate = new Date($('#dtpFrom').val());

    //   CurrentDate.setMonth(CurrentDate.getMonth() + a);
    //   $('#dtpTo').val(CurrentDate.toISOString().split('T')[0]);

    // });



  })
</script>