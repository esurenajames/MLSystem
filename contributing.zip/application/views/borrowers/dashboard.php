
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Borrower List
    </h1>
    <ol class="breadcrumb">
      <li><a href="#" class="active"><i class="fa fa-dashboard"></i> Dashboard</a></li>
      <li>Borrower List</a></li>
      Dashboard
    </h1>
    </ol>
  </section>


  <div class="modal fade" id="modalNewCustomer">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">Borrower Details</h4>
        </div>
        <form action="<?php echo base_url(); ?>borrower_controller/borrowerProcessing/1" id="frmInsert2" method="post">
          <div class="modal-body">
              <div class="row">
                <div class="col-md-2">
                  <div class="form-group">
                    <label for="selectNationality">Salutation</label><br>
                    <select class="form-control" style="width: 100%" required="" name="SalutationId" id="selectSalutation">
                      <?php
                        foreach ($Salutation as $rows)
                        {
                          echo '<option value="'.$rows["SalutationId"].'">'.$rows["Name"].'</option>';
                        }
                      ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtFirstName">First Name <span class="text-red">*</span> </label>
                    <input type="text" class="form-control" id="txtFirstName" required="" name="FirstName" placeholder="First Name">
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label for="txtMiddleName">Middle Name</label>
                    <input type="text" class="form-control" id="txtMiddleName" name="MiddleName" placeholder="Middle Name">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtLastName">Last Name <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtLastName" required="" name="LastName"  placeholder="Last Name">
                  </div>
                </div>
                <div class="col-md-2">
                  <div class="form-group">
                    <label for="txtExtensionName">Ext. Name</label>
                    <input type="text" class="form-control" id="txtExtensionName" name="ExtName" placeholder="Ext Name">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="selectGender">Gender <span class="text-red">*</span></label><br>
                    <select class="form-control" style="width: 100%" required="" name="SexId" id="selectGender">
                      <?php
                        foreach ($Sex as $rows)
                        {
                          echo '<option value="'.$rows["SexId"].'">'.$rows["Name"].'</option>';
                        }
                      ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="selectNationality">Nationality <span class="text-red">*</span></label><br>
                    <select class="form-control select2" style="width: 100%" required="" name="NationalityId" id="selectNationality">
                      <?php
                        foreach ($Nationality as $rows)
                        {
                          echo '<option value="'.$rows["NationalityId"].'">'.$rows["Description"].'</option>';
                        }
                      ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="selectCivilStatus">Civil Status <span class="text-red">*</span></label><br>
                    <select class="form-control" style="width: 100%" required="" name="CivilStatusId" id="selectCivilStatus">
                      <?php
                        foreach ($CivilStatus as $rows)
                        {
                          echo '<option value="'.$rows["CivilStatusId"].'">'.$rows["Name"].'</option>';
                        }
                      ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="txtContactNumber">Cellphone Number</label>
                    <input type="text" class="form-control" id="txtContactNumber" required="" name="ContactNumber" placeholder="Mobile Number">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="txtTelephone">Telephone Number</label>
                    <input type="text" class="form-control" id="txtTelephone" name="TelephoneNumber" placeholder="Mobile Number">
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="txtEmail">Email Address <span class="text-red">*</span></label>
                    <input type="email" class="form-control" required="" id="txtEmail" name="EmailAddress" required="" placeholder="Email Address">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <div class="form-group">
                        <label>Date of Birth <span class="text-red">*</span></label>
                        <div class="input-group date">
                          <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                          </div>
                          <input type="text" class="form-control" name="DOB" required="" id="datepicker">
                        </div>
                        <!-- /.input group -->
                      </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="txtDependents">No. of Dependents <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtDependents" name="NoDependents" required="" placeholder="No. of dependents">
                  </div>
                </div>
                <div class="col-md-12">
                  <center><label>CITY ADDRESS</label></center>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="txtHouseNo">House No. <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="HouseNo" required="" placeholder="House No.">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="txtStreet">Street <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="" placeholder="Street">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="selectRegion">Region <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" onchange="changeRegion(this.value)" id="selectRegion" name="RegionId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="selectRegion">Province <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" id="selectProvince" onchange="changeProvince(this.value)" name="ProvinceId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="selectCity">City <span class="text-red">*</span></label>
                    <select class="form-control select2" required="" id="selectCity" onchange="changeCity(this.value)" name="CityId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="selectBarangay">Barangay <span class="text-red">*</span></label>
                    <select class="form-control select2" required="" id="selectBarangay" name="BarangayId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-12">
                  <label>Length of stay in city address</label><br>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtYearsStayed">Years<span class="text-red">*</span></label>
                    <input type="number" min="0" class="form-control" id="txtYearsStayed" name="YearsStayed" required="" placeholder="Years stayed">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtMonthsStayed">Months <span class="text-red">*</span></label>
                    <input type="number" min="0" max="11" maxlength="2" class="form-control" id="txtMonthsStayed" name="MonthsStayed" required="" placeholder="Months stayed">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtTelephoneCityAddress">Telephone at city address</label>
                    <input type="text" class="form-control" id="txtTelephoneCityAddress" name="TelephoneCityAddress" placeholder="Telephone number for city address">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtTelephoneCityAddress">Cellphone at city address</label>
                    <input type="text" class="form-control" id="txtCellphoneCityAdd" name="CellphoneCityAdd" placeholder="Cellphone number for city address">
                  </div>
                </div>
                <div class="col-md-12">
                  <label>Type of Residence</label><br>
                  <div class="form-group">
                    <div class="radio">
                      <label>
                        <input type="radio" name="optionsRadios" id="optionsRadios1" onclick="chkRent(this.value)" value="Owned" checked="">
                        Owned - Mortgage
                      </label>
                      <label>
                        <input type="radio" name="optionsRadios" id="optionsRadios2" onclick="chkRent(this.value)" value="Living with relatives">
                        Living with relatives
                      </label>
                      <label>
                        <input type="radio" name="optionsRadios" id="optionsRadios3" onclick="chkRent(this.value)" value="Rented">
                        Rented
                      </label>
                    </div>
                    <div class="row">
                      <div id="divRentedDetails" style="display: none">
                        <input type="hidden" class="form-control" id="txtRentedType" name="isRented" required="">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="txtLandLord">Name of Landlord</label>
                            <input type="text" class="form-control" id="txtLandLord" name="LandLord" placeholder="Name of Landlord/Lessor">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="txtLandLordNumber">Telephone No.</label>
                            <input type="text" class="form-control" id="txtLandLordNumber" name="LandLordNumber" placeholder="Telephone Number">
                          </div>
                        </div>
                      </div>
                    </div>
                </div>



                </div>
                <div class="col-md-12">
                  <center><label>PROVINCIAL ADDRESS</label> <br> 
                    <label><input type="checkbox" class="minimal" id="chkAddress" name="SameAddress" value="1" onclick="chkFunction(this.value)"> Same as customer address </label>
                    <input type="hidden" class="form-control" required="" id="txtAddress2" name="IsSameAddress" required="">
                  </center>
                </div>
              </div>
              <div class="row">
                <div id="divProvincialAddress">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="txtHouseNo2">House No. <span class="text-red">*</span></label>
                      <input type="text" class="form-control" id="txtHouseNo2" name="HouseNo2" placeholder="House No.">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="txtStreet2">Street <span class="text-red">*</span></label>
                      <input type="text" class="form-control" id="txtStreet2" name="StreetNo2" placeholder="Street">
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="selectRegion2">Region <span class="text-red">*</span></label>
                      <select class="form-control select2"  onchange="changeRegion2(this.value)" id="selectRegion2" name="RegionId2" style="width: 100%">
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="selectProvince2">Province <span class="text-red">*</span></label>
                      <select class="form-control select2"  id="selectProvince2" onchange="changeProvince2(this.value)" name="ProvinceId2" style="width: 100%">
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="selectCity2">City <span class="text-red">*</span></label>
                      <select class="form-control select2" id="selectCity2" onchange="changeCity2(this.value)" name="CityId2" style="width: 100%">
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="selectBarangay2">Barangay <span class="text-red">*</span></label>
                      <select class="form-control select2" id="selectBarangay2" name="BarangayId2" style="width: 100%">
                      </select>
                    </div>
                  </div>
                </div>
              </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
  </div>

    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">List of Borrowers</h3>
        </div>
        <div class="box-body">
          <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewRecord">Add Borrower</button>
          <br>
          <br>
          <form name="ApproverDocForm" method="post" id="ApproverDocForm">
            <table id="example1" class="table table-bordered table-hover">
              <thead>
              <tr>
                <th>Borrower Name</th>
                <th>No. of Dependents</th>
                <th>No. of Loans</th>
                <th>Added By</th>
                <th>Status</th>
                <th>Date Created</th>
                <th>Date Updated</th>
                <th>Action</th>
              </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
          </form>
        </div>
      </div>
    </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1.0.0
  </div>
  <strong>Copyright &copy; 2020 <a href="https://adminlte.io">GIA Tech.</a>.</strong> All rights
  reserved.
</footer>

<div class="loading" style="display: none">Loading&#8230;</div>
<?php $this->load->view('includes/footer'); ?>

<script>
  var varStatus = 0;
  var varNewPassword = 0;
  function changeRegion(RegionId)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getProvinces",
      method: "POST",
      data: { RegionId : RegionId },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectProvince').html(data);
      }
    })
  }

  function changeProvince(ProvinceCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getCities",
      method: "POST",
      data: { Id : ProvinceCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectCity').html(data);
      }
    })
  }

  function changeCity(CityCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getBarangays",
      method: "POST",
      data: { Id : CityCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectBarangay').html(data);
      }
    })
  }
  function changeRegion2(RegionId)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getProvinces",
      method: "POST",
      data: { RegionId : RegionId },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectProvince2').html(data);
      }
    })
  }

  function changeProvince2(ProvinceCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getCities",
      method: "POST",
      data: { Id : ProvinceCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectCity2').html(data);
      }
    })
  }

  function changeCity2(CityCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getBarangays",
      method: "POST",
      data: { Id : CityCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectBarangay2').html(data);
      }
    })
  }

  function chkFunction()
  {
    // Get the checkbox
    var checkBox = document.getElementById("chkAddress");
    // If the checkbox is checked, display the output text
    if (checkBox.checked == true){
      $('#divProvincialAddress').slideUp();
      $('#txtAddress2').val(1);
    } else {
      $('#divProvincialAddress').slideDown();
      $('#txtAddress2').val(0);
    }
  }

  function chkRent()
  {
    var radioValue = $("input[name='optionsRadios']:checked").val();
    if(radioValue == 'Rented'){
      $('#divRentedDetails').slideDown();
      $('#txtRentedType').val(1);
    }
    else
    {
      $('#divRentedDetails').slideUp();
      $('#txtRentedType').val(0);
    }
  }

  function confirm(Text, UserRoleId, updateType)
  { 
    swal({
      title: 'Confirm',
      text: Text,
      type: 'info',
      showCancelButton: true,
      buttonsStyling: false,
      confirmButtonClass: 'btn btn-success',
      confirmButtonText: 'Confirm',
      cancelButtonClass: 'btn btn-secondary'
    }).then(function(){
      $.ajax({                
          url: "<?php echo base_url();?>" + "/employee_controller/updateStatus",
          method: "POST",
          data:   {
                    UserRoleId : UserRoleId
                    , updateType : updateType
                  },
          beforeSend: function(){
              $('.loading').show();
          },
          success: function(data)
          {
            refreshPage();
            swal({
              title: 'Success!',
              text: 'User role successfully deactivated!',
              type: 'success',
              buttonsStyling: false,
              confirmButtonClass: 'btn btn-primary'
            });
          },
          error: function (response) 
          {
            refreshPage();
            swal({
              title: 'Warning!',
              text: 'Something went wrong, please contact the administrator or refresh page!',
              type: 'warning',
              buttonsStyling: false,
              confirmButtonClass: 'btn btn-primary'
            });
          }
      });
    });
  }

  function refreshPage(){
    var url = '<?php echo base_url()."datatables_controller/Users/"; ?>';
    UserTable.ajax.url(url).load();
  }

  $(function () {
    $('.select2').select2();

    $('#selectRegion').select2({
      placeholder: 'Type region',
      minimumInputLength: 3, // only start searching when the user has input 3 or more characters
      ajax: {
        url: '<?php echo base_url()?>/admin_controller/getRegion?>',
        dataType: 'json',
        delay: 250,
        processResults: function (data) 
        { 
          return {
            results: data
          };
        },
        cache: true
      }
    });

    $('#selectRegion2').select2({
      placeholder: 'Type region',
      minimumInputLength: 3, // only start searching when the user has input 3 or more characters
      ajax: {
        url: '<?php echo base_url()?>/admin_controller/getRegion?>',
        dataType: 'json',
        delay: 250,
        processResults: function (data) 
        { 
          return {
            results: data
          };
        },
        cache: true
      }
    });
    
    $('#example1').DataTable({
      "pageLength": 10,
      "ajax": { url: '<?php echo base_url()."/borrower_controller/getAllList/"; ?>', type: 'POST', "dataSrc": "" },
      "columns": [  { 
                        data: "FirstName", "render": function (data, type, row) {
                          if(row.ExtName == '' && row.MI != '')
                          {
                            return row.LastName + ', ' +  row.FirstName + ' ' +  row.MI + '.';;
                          }
                          else if(row.MI == '')
                          {
                            return row.LastName + ', ' +  row.FirstName + ' ' +  row.ExtName;
                          }
                          else
                          {
                            return row.LastName + ', ' +  row.FirstName +  row.MI;
                          }
                      }
                    }
                    , { data: "Dependents" }
                    , { data: "TotalLoans" }
                    , { data: "Name" }
                    , { data: "StatusId", "render": function (data, type, row) {
                        if(row.StatusId == 1){
                          return "<span class='badge bg-red'>"+row.StatusDescription+"</span>";
                        }
                        else if(row.StatusId == 2){
                          return "<span class='badge bg-green'>"+row.StatusDescription+"</span>";
                        }
                        else{
                          return "N/A";
                        }
                      }
                    },
                    { data: "DateCreated" }, 
                    { data: "DateUpdated" }, 
                    {
                      data: "StatusId", "render": function (data, type, row) {
                      if(row.StatusId == 1){
                          return '<a onclick="confirm(\'Are you sure you want to re-activate this user?\', \''+row.BorrowerId+'\', 2)" class="btn btn-success" title="Deactivate"><span class="fa fa-refresh"></span></a>';
                        }
                        else if(row.StatusId == 2){
                          return '<a href="<?php echo base_url()."home/BorrowerDetails/"; ?>'+row.BorrowerId+'" class="btn btn-default" title="View"><span class="fa fa-info-circle"></span></a> <a onclick="confirm(\'Are you sure you want to deactivate this user?\', \''+row.BorrowerId+'\', 1)" class="btn btn-danger" title="Deactivate"><span class="fa fa-close"></span></a>';
                        }
                        else{
                          return "N/A";
                        }
                      }
                    },
      ],
      // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
      "order": [[3, "asc"]]
    });

    $("#frmInsert2").on('submit', function (e) {
      e.preventDefault(); 
      swal({
        title: 'Confirm',
        text: 'Are you sure you want to add this to the borrower list?',
        type: 'info',
        showCancelButton: true,
        buttonsStyling: false,
        confirmButtonClass: 'btn btn-success',
        confirmButtonText: 'Confirm',
        cancelButtonClass: 'btn btn-secondary'
      }).then(function(){
        e.currentTarget.submit();
      });
    });
    

    if("<?php print_r($this->session->flashdata('alertTitle')) ?>" != '')
    {
      swal({
        title: '<?php print_r($this->session->flashdata('alertTitle')) ?>',
        text: '<?php print_r($this->session->flashdata('alertText')) ?>',
        type: '<?php print_r($this->session->flashdata('alertType')) ?>',
        buttonsStyling: false,
        confirmButtonClass: 'btn btn-primary'
      });
    }

    $('#datepicker').daterangepicker({
        "startDate": moment().format('DD MMM YY hh:mm A'),
        "singleDatePicker": true,
        "timePicker": false,
        "linkedCalendars": false,
        "showCustomRangeLabel": false,
        // "maxDate": Start,
        "opens": "up",
        "locale": {
            format: 'DD MMM YYYY',
        },
    }, function(start, end, label){
    });



    $('#modalNewPassword').modal('show')
  })
</script>