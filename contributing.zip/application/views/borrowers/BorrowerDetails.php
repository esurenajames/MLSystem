
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Details for <?php print_r($detail['LastName'] . ', ' . $detail['FirstName'] . ' '  . $detail['MiddleInitial']) ?>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#" class="active"><i class="fa fa-dashboard"></i> Details</a></li>
      <li><a href="#">Borrower Details</a></li>
    </ol>
  </section>

  <!-- Main content -->
  <section class="content">


    <div class="modal fade" id="modalEditDetails">
      <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">CHANGE PASSWORD</h4>
        </div>
          <form action="<?php echo base_url(); ?>employee_controller/ResetPassword/1" id="frmInsert" method="post">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="colorCurrent">Current Password</label>
                    <div class="form-group" id="colorCurrent">
                      <label class="control-label" id="lblSuccess" style="display: none" for="inputSuccess"><i class="fa fa-check"></i></label>
                      <input type="text" class="form-control" name="NewPassword" id="txtCurrentPassword" oninput="checkCurrentPassword(this.value);" placeholder="Enter Current password">
                      <span id="successMessage3" style="display: none" class="help-block"></span>
                    </div>
                    <!-- <input type="password" id="txtNewPassword" class="form-control" id="exampleInputEmail1"> -->
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="exampleInputEmail1">New Password</label>
                    <div class="form-group" id="colorSuccess">
                      <label class="control-label" id="lblSuccess" style="display: none" for="inputSuccess"><i class="fa fa-check"></i></label>
                      <input type="text" class="form-control" name="NewPassword" id="txtNewPassword" oninput="checkNewPassword(this.value);" placeholder="Enter New password">
                      <span id="successMessage" style="display: none" class="help-block"></span>
                    </div>
                    <!-- <input type="password" id="txtNewPassword" class="form-control" id="exampleInputEmail1"> -->
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Confirm Password</label>
                    <div class="form-group" id="colorSuccess2">
                      <label class="control-label" id="lblSuccess2" style="display: none" for="txtConfirmPassword"><i class="fa fa-check"></i></label>
                      <input type="text" class="form-control" id="txtConfirmPassword" oninput="checkPasswordMatch(this.value);">
                      <span id="successMessage2" style="display: none" class="help-block"></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
          </form>
      </div>
      <!-- /.modal-content -->
      </div>
    <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modalNewContact">
      <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">ADD CONTACT</h4>
        </div>
          <form action="<?php echo base_url(); ?>borrower_controller/AddContact/<?php print_r($detail['BorrowerId']) ?>" id="frmInsert" method="post">
            <input type="hidden" class="form-control" id="txtContactNumber" required="" name="FormType" value="1" placeholder="Mobile Number">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label for="txtContactNumber">Number</label>
                    <input type="text" class="form-control" id="txtContactNumber" name="ContactNumber" placeholder="09----------">
                  </div>
                </div>
                <div class="radio">
                  <label>
                    <input type="radio" name="ContactType" id="optionsRadios1" onclick="chkEmployeeType(this.value)" value="Mobile" checked="">
                    Mobile
                  </label>
                  <label>
                    <input type="radio" name="ContactType" id="optionsRadios2" onclick="chkEmployeeType(this.value)" value="Telephone">
                    Telephone
                  </label>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit Contact</button>
            </div>
          </form>
      </div>
      <!-- /.modal-content -->
      </div>
    <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modalNewEmail">
      <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">ADD EMAIL ADDRESS</h4>
        </div>
          <form action="<?php echo base_url(); ?>borrower_controller/AddEmail/1" id="frmInsert" method="post">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="colorCurrent">Email Address</label>
                    <div class="form-group" id="colorCurrent">
                      <input type="text" class="form-control" name="Email" id="txtEmail" placeholder="@yahoo.com">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit Email</button>
            </div>
          </form>
      </div>
      <!-- /.modal-content -->
      </div>
    <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modalNewAddress">
      <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">ADD ADDRESS</h4>
        </div>
          <form action="<?php echo base_url(); ?>borrower_controller/AddAddress/1" id="frmInsert" method="post">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="txtHouseNo">House No. <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="HouseNo" required="" placeholder="House No.">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="txtStreet">Street <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="" placeholder="Street">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="selectRegion">Region <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" onchange="changeRegion(this.value)" id="selectRegion" name="RegionId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="selectRegion">Province <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" id="selectProvince" onchange="changeProvince(this.value)" name="ProvinceId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="selectCity">City <span class="text-red">*</span></label>
                    <select class="form-control select2" required="" id="selectCity" onchange="changeCity(this.value)" name="CityId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="selectBarangay">Barangay <span class="text-red">*</span></label>
                    <select class="form-control select2" required="" id="selectBarangay" name="BarangayId" style="width: 100%">
                    </select>
                  </div>
                  <div class="radio">
                    <label>
                      <input type="radio" name="EmployeeType" id="optionsRadios1" onclick="chkEmployeeType(this.value)" value="Provincial" checked="">
                      Provincial
                    </label>
                    <label>
                      <input type="radio" name="EmployeeType" id="optionsRadios2" onclick="chkEmployeeType(this.value)" value="City">
                      City
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit Address</button>
            </div>
          </form>
      </div>
      <!-- /.modal-content -->
      </div>
    <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modalNewPersonal">
      <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">ADD PERSONAL REFERENCE</h4>
        </div>
          <form action="<?php echo base_url(); ?>borrower_controller/AddPersonal/1" id="frmInsert" method="post">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">First Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="FirstName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Middle Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="MiddleName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Last Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="LastName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Ext. Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="ExtName">
                  </div>
                </div>
                <br>
                <div class="col-md-12">
                  <center><label>PERSONAL ADDRESS</label></center>
                </div>
                <br>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtStreet">Street <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="" placeholder="Street">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectRegion">Region <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" onchange="changeRegion(this.value)" id="selectRegion" name="RegionId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectRegion">Province <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" id="selectProvince" onchange="changeProvince(this.value)" name="ProvinceId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectCity">City <span class="text-red">*</span></label>
                    <select class="form-control select2" required="" id="selectCity" onchange="changeCity(this.value)" name="CityId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectBarangay">Barangay <span class="text-red">*</span></label>
                    <select class="form-control select2" required="" id="selectBarangay" name="BarangayId" style="width: 100%">
                    </select>
                  </div>
                  <div class="col-md-3">
                    <div class="radio">
                      <label>
                        <input type="radio" name="EmployeeType" id="optionsRadios1" onclick="chkEmployeeType(this.value)" value="Provincial" checked="">
                        Provincial
                      </label>
                      <label>
                        <input type="radio" name="EmployeeType" id="optionsRadios2" onclick="chkEmployeeType(this.value)" value="City">
                        City
                      </label>
                    </div>
                  </div>
                </div>
                <br>
                <div class="col-md-12">
                  <center><label>CONTACT</label></center>
                </div>
                <br>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtStreet">Contact Number <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectRegion">Type <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" onchange="changeRegion(this.value)" id="selectRegion" name="RegionId" style="width: 100%">
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit Reference</button>
            </div>
          </form>
      </div>
      <!-- /.modal-content -->
      </div>
    <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modalNewCoMaker">
      <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">ADD CO-MAKER</h4>
        </div>
          <form action="<?php echo base_url(); ?>borrower_controller/AddCoMaker/1" id="frmInsert" method="post">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">First Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="FirstName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Middle Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="MiddleName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Last Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="LastName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Ext. Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="ExtName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Employer / Business Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="ExtName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Position<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="ExtName">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <div class="form-group">
                        <label>Date Hired <span class="text-red">*</span></label>
                        <div class="input-group date">
                          <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                          </div>
                          <input type="text" class="form-control" name="DateHired" required="" id="dateHired">
                        </div>
                        <!-- /.input group -->
                      </div>
                  </div>
                </div>
                <br>
                <div class="col-md-12">
                  <center><label>CONTACT</label></center>
                </div>
                <br>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="txtStreet">Contact Number <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="selectRegion">Type <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" onchange="changeRegion(this.value)" id="selectRegion" name="RegionId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <br>
                <div class="col-md-12">
                  <center><label>PERSONAL ADDRESS</label></center>
                </div>
                <br>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtStreet">Street <span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="" placeholder="Street">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectRegion">Region <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" onchange="changeRegion(this.value)" id="selectRegion" name="RegionId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectRegion">Province <span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" id="selectProvince" onchange="changeProvince(this.value)" name="ProvinceId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectCity">City <span class="text-red">*</span></label>
                    <select class="form-control select2" required="" id="selectCity" onchange="changeCity(this.value)" name="CityId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectBarangay">Barangay <span class="text-red">*</span></label>
                    <select class="form-control select2" required="" id="selectBarangay" name="BarangayId" style="width: 100%">
                    </select>
                  </div>
                  <div class="col-md-3">
                    <div class="radio">
                      <label>
                        <input type="radio" name="EmployeeType" id="optionsRadios1" onclick="chkEmployeeType(this.value)" value="Provincial" checked="">
                        Provincial
                      </label>
                      <label>
                        <input type="radio" name="EmployeeType" id="optionsRadios2" onclick="chkEmployeeType(this.value)" value="City">
                        City
                      </label>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label for="txtStreet">Tenure<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="">
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit Co-Maker</button>
            </div>
          </form>
      </div>
      <!-- /.modal-content -->
      </div>
    <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modalNewSpouse">
      <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">ADD SPOUSE RECORD</h4>
        </div>
          <form action="<?php echo base_url(); ?>borrower_controller/AddSpouse/1" id="frmInsert" method="post">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">First Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="FirstName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Middle Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="MiddleName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Last Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="LastName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Ext. Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="ExtName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                      <div class="form-group">
                        <label>Date of Birth <span class="text-red">*</span></label>
                        <div class="input-group date">
                          <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                          </div>
                          <input type="text" class="form-control" name="DateOfBirth" required="" id="datepicker">
                        </div>
                        <!-- /.input group -->
                      </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectGender">Gender <span class="text-red">*</span></label><br>
                    <select class="form-control" style="width: 100%" required="" name="SexId" id="selectGender">
                      <?php
                        foreach ($Sex as $rows)
                        {
                          echo '<option value="'.$rows["SexId"].'">'.$rows["Name"].'</option>';
                        }
                      ?>
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectCivilStatus">Civil Status <span class="text-red">*</span></label><br>
                    <select class="form-control" style="width: 100%" required="" name="CivilStatusId" id="selectCivilStatus">
                      <?php
                        foreach ($CivilStatus as $rows)
                        {
                          echo '<option value="'.$rows["CivilStatusId"].'">'.$rows["Name"].'</option>';
                        }
                      ?>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit Spouse Record</button>
            </div>
          </form>
      </div>
      <!-- /.modal-content -->
      </div>
    <!-- /.modal-dialog -->
    </div>

    <div class="modal fade" id="modalNewEmployment">
      <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title">ADD EMPLOYMENT</h4>
        </div>
          <form action="<?php echo base_url(); ?>borrower_controller/AddEmployment/1" id="frmInsert" method="post">
            <div class="modal-body">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Employer / Business Name<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="FirstName">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtHouseNo">Position<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtHouseNo" name="MiddleName">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                      <div class="form-group">
                        <label>Date Hired<span class="text-red">*</span></label>
                        <div class="input-group date">
                          <div class="input-group-addon">
                            <i class="fa fa-calendar"></i>
                          </div>
                          <input type="text" class="form-control" name="DateHired" required="" id="dateHired">
                        </div>
                        <!-- /.input group -->
                      </div>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtStreet">Contact Number<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="">
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="selectRegion">Type<span class="text-red">*</span></label>
                    <select class="form-control select2"  required="" onchange="changeRegion(this.value)" id="selectRegion" name="RegionId" style="width: 100%">
                    </select>
                  </div>
                </div>
                <div class="col-md-3">
                  <div class="form-group">
                    <label for="txtStreet">Address<span class="text-red">*</span></label>
                    <input type="text" class="form-control" id="txtStreet" name="StreetNo" required="">
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit Reference</button>
            </div>
          </form>
      </div>
      <!-- /.modal-content -->
      </div>
    <!-- /.modal-dialog -->
    </div>

    <div class="box">
      <div class="box-header with-border">
        <h3 class="box-title">Personal Information</h3>
        <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewRecord">Edit Borrower</button>
      </div>
      <div class="box-body">
        <div class="row">
          <div class="col-md-3">
            <label>Borrower Number</label>
            <h6><?php print_r($detail['BorrowerId']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Full Name</label>
            <h6><?php print_r($detail['LastName'] . ', ' . $detail['FirstName'] . ' '  . $detail['MiddleInitial']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Salutation</label>
            <h6><?php print_r($detail['Salutation']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Sex</label>
            <h6><?php print_r($detail['Sex']) ?></h6>
          </div>
        </div>
        <br>
        <br>
        <div class="row">
          <div class="col-md-3">
            <label>Civil Status</label>
            <h6><?php print_r($detail['CivilStatus']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Date of Birth</label>
            <h6><?php print_r($detail['DateOfBirth']) ?></h6>
          </div>
          <div class="col-md-3">
            <label>Status</label>
            <h6><?php print_r($detail['StatusDescription'])?></h6>
          </div>
          <div class="col-md-3">
            <label>No. of Dependents</label>
            <h6><?php print_r($detail['Dependents'])?></h6>
          </div>
        </div>
      </div>
    </div>

    <div class="box">
      <div class="box-body">
        <div class="col-md-12">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#Contact" data-toggle="tab">Contact Info</a></li>
              <li><a href="#Address" data-toggle="tab">Address Info</a></li>
              <li><a href="#Personal" data-toggle="tab">Personal Reference</a></li>
              <li><a href="#CoMaker" data-toggle="tab">Co-Maker Info</a></li>
              <li><a href="#Spouse" data-toggle="tab">Spouse Info</a></li>
              <li><a href="#Employement" data-toggle="tab">Employement Info</a></li>
            </ul>
            <div class="tab-content">
              <div class="active tab-pane" id="Contact">
              <ul class="nav nav-tabs">
                <li class="active"><a href="#Contact" data-toggle="tab">Contact No.</a></li>
                <li><a href="#Email" data-toggle="tab">Email Address</a></li>
              </ul> 
              <br>
                <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewContact">Add Contacts</button>
                <br>
                <br>
                <br>
                <table id="example1" class="table table-bordered table-hover" style="width: 100%">
                  <thead>
                  <tr>
                    <th>Contact Number</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane" id="Email">
                <ul class="nav nav-tabs">
                  <li><a href="#Contact" data-toggle="tab">Contact No.</a></li>
                  <li><a href="#Email" data-toggle="tab">Email Address</a></li>
                </ul> 
                <br>
                <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewEmail">Add Email Address</button>
                <br>
                <br>
                <br>
                <table id="example2" class="table table-bordered table-hover" style="width: 100%">
                  <thead>
                  <tr>
                    <th>Email Address</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>

              <div class="tab-pane" id="Address">
              <br>
                <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewAddress">Add Address</button>
                <br>
                <br>
                <br>
                <table id="example3" class="table table-bordered table-hover" style="width: 100%">
                  <thead>
                  <tr>
                    <th>Address</th>
                    <th>Type</th>
                    <th>Contact Number</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane" id="Personal">
                <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewPersonal">Add Personal Reference</button>
                <br>
                <br>
                <br>
                <table id="example5" class="table table-bordered table-hover" style="width: 100%">
                  <thead>
                  <tr>
                    <th>Name</th>
                    <th>City Address</th>
                    <th>Contact Number</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane" id="CoMaker">
                <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewCoMaker">Add Co-Maker</button>
                <br>
                <br>
                <br>
                <table id="example6" class="table table-bordered table-hover" style="width: 100%">
                  <thead>
                  <tr>
                    <th>Full Name</th>
                    <th>Employer/Business</th>
                    <th>Position</th>
                    <th>Date Hired</th>
                    <th>Telephone No.</th>
                    <th>Tenure</th>
                    <th>Business Address</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane" id="Spouse">
                <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewSpouse">Add Spouse</button>
                <br>
                <br>
                <br>
                <table id="example7" class="table table-bordered table-hover" style="width: 100%">
                  <thead>
                  <tr>
                    <th>Full Name</th>
                    <th>Birth Date</th>
                    <th>Gender</th>
                    <th>Civil Status</th>
                    <th>No. of Dependents</th>
                    <th>Birth Place</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>
              <div class="tab-pane" id="Employement">
                <button type="button" class="btn btn-primary pull-right" data-toggle="modal" data-target="#modalNewEmployment">Add Employment Record</button>
                <br>
                <br>
                <br>
                <table id="example8" class="table table-bordered table-hover" style="width: 100%">
                  <thead>
                  <tr>
                    <th>Employer/Business</th>
                    <th>Position</th>
                    <th>Date Hired</th>
                    <th>Telephone No.</th>
                    <th>Tenure</th>
                    <th>Business Address</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                  </thead>
                  <tbody>
                  </tbody>
                </table>
              </div>

            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
      </div>
    </div>
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 1.0.0
  </div>
  <strong>Copyright &copy; 2020 <a href="https://adminlte.io">GIA Tech.</a>.</strong> All rights
  reserved.
</footer>

<div class="loading" style="display: none">Loading&#8230;</div>
<?php $this->load->view('includes/footer'); ?>

<script>
  function ChangePassword()
  {
    $('#modalChangePassword').modal('show');
  }

  if("<?php print_r($this->session->flashdata('alertTitle')) ?>" != '')
  {
    swal({
      title: '<?php print_r($this->session->flashdata('alertTitle')) ?>',
      text: '<?php print_r($this->session->flashdata('alertText')) ?>',
      type: '<?php print_r($this->session->flashdata('alertType')) ?>',
      buttonsStyling: false,
      confirmButtonClass: 'btn btn-primary'
    });
  }

  function changeRegion(RegionId)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getProvinces",
      method: "POST",
      data: { RegionId : RegionId },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectProvince').html(data);
      }
    })
  }

  function changeProvince(ProvinceCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getCities",
      method: "POST",
      data: { Id : ProvinceCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectCity').html(data);
      }
    })
  }

  function changeCity(CityCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getBarangays",
      method: "POST",
      data: { Id : CityCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectBarangay').html(data);
      }
    })
  }

  function changeRegion2(RegionId)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getProvinces",
      method: "POST",
      data: { RegionId : RegionId },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectProvince2').html(data);
      }
    })
  }

  function changeProvince2(ProvinceCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getCities",
      method: "POST",
      data: { Id : ProvinceCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectCity2').html(data);
      }
    })
  }

  function changeCity2(CityCode)
  {
    $.ajax({
      url: "<?php echo base_url();?>" + "/admin_controller/getBarangays",
      method: "POST",
      data: { Id : CityCode },
      beforeSend: function(){
        $('.loading').show();
      },
      success: function(data)
      {
        $('#selectBarangay2').html(data);
      }
    })
  }

  function refreshPage(){
    var url = '<?php echo base_url()."datatables_controller/Users/"; ?>';
    UserTable.ajax.url(url).load();
  }

  function checkPasswordMatch(Password)
  {
    var element = document.getElementById("colorSuccess2");
    if($('#txtNewPassword').val() != Password)
    {
      element.classList.remove("has-success");
      element.classList.add("has-error");
      $('#successMessage2').slideDown();
      $('#successMessage2').html('Password does not match');
      varStatus = 0;
    }
    else
    {
      element.classList.remove("has-error");
      element.classList.add("has-success");
      $('#successMessage2').slideDown();
      $('#successMessage2').html('Password matching');
      varStatus = 1;
    }
  }

  function checkNewPassword(Password)
  {
    var element = document.getElementById("colorSuccess2");
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W\_])[A-Za-z\d\W\_]{8,}$/;
    const str = $('#txtNewPassword').val();
    let m;
    if($('#txtConfirmPassword').val() != Password)
    {
      element.classList.remove("has-success");
      element.classList.add("has-error");
      $('#successMessage2').slideDown();
      $('#successMessage2').html('Password does not match');
      varStatus = 0;
    }
    else
    {
      element.classList.remove("has-error");
      element.classList.add("has-success");
      $('#successMessage2').slideDown();
      $('#successMessage2').html('Password matching');
      varStatus = 1;
    }

    if ((m = regex.exec(str)) !== null) {
        // The result can be accessed through the `m`-variable.
        m.forEach((match, groupIndex) => {
          var element = document.getElementById("colorSuccess");
          element.classList.remove("has-error");
          element.classList.add("has-success");
          $('#successMessage').slideDown();
          $('#successMessage').html('Valid Password');
          varNewPassword = 1;
        });
    }
    else
    {
      var element = document.getElementById("colorSuccess");
      element.classList.remove("has-success");
      element.classList.add("has-error");
      $('#successMessage').slideDown();
      $('#successMessage').html('Password must contain a special, numeric and an uppercase character');
      varNewPassword = 0;
    }

  }

  $(function () {

    $("#frmInsert").on('submit', function (e) {
      if(varNewPassword = 1 && varStatus == 1 && $('#txtNewPassword').val() == $('#txtConfirmPassword').val() && $('#txtOldPassword').val() != $('#txtNewPassword').val())
      {
        e.preventDefault(); 
        swal({
          title: 'Confirm',
          text: 'Are you sure you sure with this password?',
          type: 'info',
          showCancelButton: true,
          buttonsStyling: false,
          confirmButtonClass: 'btn btn-success',
          confirmButtonText: 'Confirm',
          cancelButtonClass: 'btn btn-secondary'
        }).then(function(){
          e.currentTarget.submit();
        });
      }
      else
      {
        alert('please make sure your new password is not equal to your old password!')
        e.preventDefault();
      }
    });
    
    $('#selectRoles').select2({
      placeholder: 'Type a role to select',
      dropdownCssClass : 'bigdrop',
        ajax: {
          url: '<?php echo base_url()?>admin_controller/getRoles?>',
          dataType: 'json',
          delay: 250,
          processResults: function (data) 
          {
            return {
              results: data
            };
          },
          cache: true
        }
    });

    $('#selectEmployee').select2({
      placeholder: 'Type an employee name or employee number to select.',
      dropdownCssClass : 'bigdrop',
        ajax: {
          url: '<?php echo base_url()?>admin_controller/getEmployees?>',
          dataType: 'json',
          delay: 250,
          processResults: function (data) 
          {
            return {
              results: data
            };
          },
          cache: true
        }
    });


    $('.select2').select2();

    $('#datepicker').daterangepicker({
        "startDate": moment().format('DD MMM YY hh:mm A'),
        "singleDatePicker": true,
        "timePicker": false,
        "linkedCalendars": false,
        "showCustomRangeLabel": false,
        // "maxDate": Start,
        "opens": "up",
        "locale": {
            format: 'DD MMM YYYY',
        },
    }, function(start, end, label){
    });

    $('#dateHired').daterangepicker({
        "startDate": moment().format('DD MMM YY hh:mm A'),
        "singleDatePicker": true,
        "timePicker": false,
        "linkedCalendars": false,
        "showCustomRangeLabel": false,
        // "maxDate": Start,
        "opens": "up",
        "locale": {
            format: 'DD MMM YYYY',
        },
    }, function(start, end, label){
    });

    $('#selectRegion').select2({
      placeholder: 'Type region',
      minimumInputLength: 3, // only start searching when the user has input 3 or more characters
      ajax: {
        url: '<?php echo base_url()?>/admin_controller/getRegion?>',
        dataType: 'json',
        delay: 250,
        processResults: function (data) 
        { 
          return {
            results: data
          };
        },
        cache: true
      }
    });

    $('#selectRegion2').select2({
      placeholder: 'Type region',
      minimumInputLength: 3, // only start searching when the user has input 3 or more characters
      ajax: {
        url: '<?php echo base_url()?>/admin_controller/getRegion?>',
        dataType: 'json',
        delay: 250,
        processResults: function (data) 
        { 
          return {
            results: data
          };
        },
        cache: true
      }
    });

    $('#example1').DataTable({
      "pageLength": 10,
      "ajax": { url: '<?php echo base_url()."/borrower_controller/getAllList/"; ?>', type: 'POST', "dataSrc": "" },
      "columns": [  { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    {
                      data: "StatusId", "render": function (data, type, row) {
                      if(row.StatusId == 1){
                          return '<a onclick="confirm(\'Are you sure you want to re-activate this user?\', \''+row.BorrowerId+'\', 2)" class="btn btn-success" title="Deactivate"><span class="fa fa-refresh"></span></a>';
                        }
                        else if(row.StatusId == 2){
                          return '<a href="<?php echo base_url()."home/BorrowerDetails/"; ?>'+row.BorrowerId+'" class="btn btn-default" title="View"><span class="fa fa-info-circle"></span></a> <a onclick="confirm(\'Are you sure you want to deactivate this user?\', \''+row.BorrowerId+'\', 1)" class="btn btn-danger" title="Deactivate"><span class="fa fa-close"></span></a>';
                        }
                        else{
                          return "N/A";
                        }
                      }
                    },
      ],
      // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
      "order": [[0, "asc"]]
    });

    $('#example2').DataTable({
      "pageLength": 10,
      "ajax": { url: '<?php echo base_url()."/borrower_controller/getAllList/"; ?>', type: 'POST', "dataSrc": "" },
      "columns": [  { data: "Dependents" },
                    { data: "Dependents" },
                    {
                      data: "StatusId", "render": function (data, type, row) {
                      if(row.StatusId == 1){
                          return '<a onclick="confirm(\'Are you sure you want to re-activate this user?\', \''+row.BorrowerId+'\', 2)" class="btn btn-success" title="Deactivate"><span class="fa fa-refresh"></span></a>';
                        }
                        else if(row.StatusId == 2){
                          return '<a href="<?php echo base_url()."home/BorrowerDetails/"; ?>'+row.BorrowerId+'" class="btn btn-default" title="View"><span class="fa fa-info-circle"></span></a> <a onclick="confirm(\'Are you sure you want to deactivate this user?\', \''+row.BorrowerId+'\', 1)" class="btn btn-danger" title="Deactivate"><span class="fa fa-close"></span></a>';
                        }
                        else{
                          return "N/A";
                        }
                      }
                    },
      ],
      // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
      "order": [[0, "asc"]]
    });

    $('#example3').DataTable({
      "pageLength": 10,
      "ajax": { url: '<?php echo base_url()."/borrower_controller/getAllList/"; ?>', type: 'POST', "dataSrc": "" },
      "columns": [  { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    {
                      data: "StatusId", "render": function (data, type, row) {
                      if(row.StatusId == 1){
                          return '<a onclick="confirm(\'Are you sure you want to re-activate this user?\', \''+row.BorrowerId+'\', 2)" class="btn btn-success" title="Deactivate"><span class="fa fa-refresh"></span></a>';
                        }
                        else if(row.StatusId == 2){
                          return '<a href="<?php echo base_url()."home/BorrowerDetails/"; ?>'+row.BorrowerId+'" class="btn btn-default" title="View"><span class="fa fa-info-circle"></span></a> <a onclick="confirm(\'Are you sure you want to deactivate this user?\', \''+row.BorrowerId+'\', 1)" class="btn btn-danger" title="Deactivate"><span class="fa fa-close"></span></a>';
                        }
                        else{
                          return "N/A";
                        }
                      }
                    },
      ],
      // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
      "order": [[0, "asc"]]
    });

    $('#example5').DataTable({
      "pageLength": 10,
      "ajax": { url: '<?php echo base_url()."/borrower_controller/getAllList/"; ?>', type: 'POST', "dataSrc": "" },
      "columns": [  { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    {
                      data: "StatusId", "render": function (data, type, row) {
                      if(row.StatusId == 1){
                          return '<a onclick="confirm(\'Are you sure you want to re-activate this user?\', \''+row.BorrowerId+'\', 2)" class="btn btn-success" title="Deactivate"><span class="fa fa-refresh"></span></a>';
                        }
                        else if(row.StatusId == 2){
                          return '<a href="<?php echo base_url()."home/BorrowerDetails/"; ?>'+row.BorrowerId+'" class="btn btn-default" title="View"><span class="fa fa-info-circle"></span></a> <a onclick="confirm(\'Are you sure you want to deactivate this user?\', \''+row.BorrowerId+'\', 1)" class="btn btn-danger" title="Deactivate"><span class="fa fa-close"></span></a>';
                        }
                        else{
                          return "N/A";
                        }
                      }
                    },
      ],
      // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
      "order": [[0, "asc"]]
    });

    $('#example6').DataTable({
      "pageLength": 10,
      "ajax": { url: '<?php echo base_url()."/borrower_controller/getAllList/"; ?>', type: 'POST', "dataSrc": "" },
      "columns": [  { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    {
                      data: "StatusId", "render": function (data, type, row) {
                      if(row.StatusId == 1){
                          return '<a onclick="confirm(\'Are you sure you want to re-activate this user?\', \''+row.BorrowerId+'\', 2)" class="btn btn-success" title="Deactivate"><span class="fa fa-refresh"></span></a>';
                        }
                        else if(row.StatusId == 2){
                          return '<a href="<?php echo base_url()."home/BorrowerDetails/"; ?>'+row.BorrowerId+'" class="btn btn-default" title="View"><span class="fa fa-info-circle"></span></a> <a onclick="confirm(\'Are you sure you want to deactivate this user?\', \''+row.BorrowerId+'\', 1)" class="btn btn-danger" title="Deactivate"><span class="fa fa-close"></span></a>';
                        }
                        else{
                          return "N/A";
                        }
                      }
                    },
      ],
      // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
      "order": [[0, "asc"]]
    });

    $('#example7').DataTable({
      "pageLength": 10,
      "ajax": { url: '<?php echo base_url()."/borrower_controller/getAllList/"; ?>', type: 'POST', "dataSrc": "" },
      "columns": [  { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    {
                      data: "StatusId", "render": function (data, type, row) {
                      if(row.StatusId == 1){
                          return '<a onclick="confirm(\'Are you sure you want to re-activate this user?\', \''+row.BorrowerId+'\', 2)" class="btn btn-success" title="Deactivate"><span class="fa fa-refresh"></span></a>';
                        }
                        else if(row.StatusId == 2){
                          return '<a href="<?php echo base_url()."home/BorrowerDetails/"; ?>'+row.BorrowerId+'" class="btn btn-default" title="View"><span class="fa fa-info-circle"></span></a> <a onclick="confirm(\'Are you sure you want to deactivate this user?\', \''+row.BorrowerId+'\', 1)" class="btn btn-danger" title="Deactivate"><span class="fa fa-close"></span></a>';
                        }
                        else{
                          return "N/A";
                        }
                      }
                    },
      ],
      // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
      "order": [[0, "asc"]]
    });

    $('#example8').DataTable({
      "pageLength": 10,
      "ajax": { url: '<?php echo base_url()."/borrower_controller/getAllList/"; ?>', type: 'POST', "dataSrc": "" },
      "columns": [  { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    { data: "Dependents" },
                    {
                      data: "StatusId", "render": function (data, type, row) {
                      if(row.StatusId == 1){
                          return '<a onclick="confirm(\'Are you sure you want to re-activate this user?\', \''+row.BorrowerId+'\', 2)" class="btn btn-success" title="Deactivate"><span class="fa fa-refresh"></span></a>';
                        }
                        else if(row.StatusId == 2){
                          return '<a href="<?php echo base_url()."home/BorrowerDetails/"; ?>'+row.BorrowerId+'" class="btn btn-default" title="View"><span class="fa fa-info-circle"></span></a> <a onclick="confirm(\'Are you sure you want to deactivate this user?\', \''+row.BorrowerId+'\', 1)" class="btn btn-danger" title="Deactivate"><span class="fa fa-close"></span></a>';
                        }
                        else{
                          return "N/A";
                        }
                      }
                    },
      ],
      // "aoColumnDefs": [{ "bVisible": false, "aTargets": [0] }],
      "order": [[0, "asc"]]
    });

  })
</script>