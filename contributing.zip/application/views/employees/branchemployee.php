  <div class="row">
    <div class="col-md-4">
      <label>Manager:</label>
      <h6><?php print_r($branchDetail['LastName'] . ', ' . $branchDetail['FirstName'] . ' '  . $branchDetail['MiddleInitial']) ?></h6>
    </div>
    <div class="col-md-4">
      <label>Branch</label>
      <h6><?php print_r($branchDetail['Code'] . ' - ' . $branchDetail['Name']) ?></h6>
    </div>
    <div class="col-md-4">
      <label>Description</label>
      <h6><?php print_r($branchDetail['Description']) ?></h6>
    </div>
  </div>