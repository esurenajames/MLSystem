  <div class="row">
    <div class="col-md-4">
      <label>Manager:</label>
      <h6><?php print_r($branchManager['LastName'] . ', ' . $branchManager['FirstName'] . ' '  . $branchManager['MiddleInitial']) ?></h6>
    </div>
    <div class="col-md-4">
      <label>Branch</label>
      <h6><?php print_r($branchManager['Code'] . ' - ' . $branchManager['Name']) ?></h6>
    </div>
    <div class="col-md-4">
      <label>Description</label>
      <h6><?php print_r($branchManager['Description']) ?></h6>
    </div>
  </div>