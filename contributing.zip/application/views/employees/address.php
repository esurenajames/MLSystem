<table id="dtblAddress" class="table table-bordered table-hover" style="width: 100%">
  <thead>
  <tr>
    <th>Address</th>
    <th>Type</th>
    <th>Date Created</th>
    <th>Date Updated</th>
    <th>Status</th>
    <th>Action</th>
  </tr>
  </thead>
  <tbody>
    <?php 
      foreach ($Address as $value) 
      {
        echo "<tr>";
        echo "<td>".$value['ReferenceNo']."</td>";
        echo "<td>".$value['Title']."</td>";
        echo "<td>".$value['Description']."</td>";
        echo "<td>".$value['PreparedBy']."</td>";
        echo "<td>".$value['DateApproved']."</td>";
        echo "<td>".$value['Name']."</td>";
        echo "<td>".$value['DateCreated']."</td>";

        if($value['StatusId'] == 1)
        {
          $action = '<a onclick="incidentReportConfirm('.$value['IncidentId'].', 0)" class="btn btn-sm btn-danger" title="Deactivate"><span class="fa fa-close"></span></a> <a class="btn btn-sm btn-success" href="' . base_url() .'/home/download/1/'.$value['IncidentId'].'" title="Download"><span class="fa fa-download"></span></a>';
          $status = '<p class="text-green">Active</p>';
        }
        else
        {
          $action = '<a onclick="incidentReportConfirm('.$value['IncidentId'].', 1)" class="btn btn-sm btn-warning" title="Re-activate"><span class="fa fa-refresh"></span></a> <a class="btn btn-sm btn-success" href="' . base_url() .'/home/download/1/'.$value['IncidentId'].'" title="Download"><span class="fa fa-download"></span></a>';
          $status = '<p class="text-red">Deactivated</p>';
        }
        echo "<td>".$status."</td>";
        echo "<td>".$action."</td>";
        echo "</tr>";
      }
    ?>
  </tbody>
</table>