
<table id="dtblEmailAddress" class="table table-bordered table-hover" style="width: 100%">
  <thead>
  <tr>
    <th>#</th>
    <th>Email Address</th>
    <th>Created By</th>
    <th>Is Primary?</th>
    <th>Date Created</th>
    <th>Last Updated</th>
    <th>Status</th>
    <th>Action</th>
  </tr>
  </thead>
  <tbody>
  </tbody>
</table>