<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin_controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('maintenance_model');
		$this->load->model('access');
		$this->load->model('employee_model');
		$this->load->model('admin_model');

   	if(empty($this->session->userdata("EmployeeNumber")) || $this->session->userdata("logged_in") == 0)
   	{
      $DateNow = date("Y-m-d H:i:s");
     	$this->session->set_flashdata('logout','Account successfully logged out.'); 
      $data = array(
      	'Description' => 'Session timed out.'
      	, 'DateCreated' => $DateNow
      	, 'CreatedBy' => $this->session->userdata('EmployeeNumber')
      );
      $this->access->audit($data);
      $loginSession = array(
        'logged_in' => 0,
      );
   		redirect(site_url());
   	}
	}

	function getAuditLogs()
	{
		$result = $this->admin_model->getAuditLogs();
		echo json_encode($result);
	}

  public function getEmployees()
  {
    $json = [];
    if(!empty($this->input->get("q")))
    {
      $keyword = $this->input->get("q");
      $json = $this->admin_model->getEmployees($keyword);
    }
    echo json_encode($json);
  }

  public function getRoles()
  {
    $json = [];
    if(!empty($this->input->get("q")))
    {
      $keyword = $this->input->get("q");
      $json = $this->admin_model->getRoles($keyword);
    }
    echo json_encode($json);
  }

  function SecurityQuestion()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $DateNow = date("Y-m-d H:i:s");
    if($this->uri->segment(3) == 1) // update Security Question
    {
      // audits
        $auditDetail = 'Security Question updated.';
        $insertData = array(
          'Description' => $auditDetail,
          'SecurityQuestionId' => $_POST['SecurityId'],
        );
        $auditTable = 'R_Logs';
        $this->maintenance_model->insertFunction($insertData, $auditTable);
      // insert user security question
        $insertData = array
        (
          'EmployeeNumber' => $EmployeeNumber,
          'SecurityQuestionId' => $_POST['SecurityId'],
          'Answer' => $_POST['Answer'],
        );
        $auditTable = 'R_userrole_has_r_securityquestions';
        $this->maintenance_model->insertFunction($insertData, $auditTable);
      // notification
        $this->session->set_flashdata('alertTitle','Success!'); 
        $this->session->set_flashdata('alertText','Security question successfully set!'); 
        $this->session->set_flashdata('alertType','success'); 
      
      redirect('home/userprofile');
    }
  }

  public function getRegion()
  {
    $json = [];
    if(!empty($this->input->get("q")))
    {
      $keyword = $this->input->get("q");
      $json = $this->maintenance_model->getRegion($keyword);
    }
    echo json_encode($json);
  }

  function getRegionList()
  {
    echo $this->maintenance_model->getRegionList();
  }

  function getProvinces()
  {
    echo $this->maintenance_model->getProvinces($this->input->post('RegionId'));
  }

  function getCities()
  {
    echo $this->maintenance_model->getCities($this->input->post('Id'));
  }

  function getBranches()
  {
    echo $this->maintenance_model->getBranches($this->input->post('Id'));
  }

  function getManagers()
  {
    echo $this->maintenance_model->getManagers($this->input->post('BranchId'));
  }

  function getBarangays()
  {
    echo $this->maintenance_model->getBarangays($this->input->post('Id'));
  }

  function addEmployees()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $DateNow = date("Y-m-d H:i:s");
    if($this->uri->segment(3) == 1) // update Security Question
    {
      // audits
        $auditDetail = 'Security question updated.';
        $insertData = array(
          'Description' => $auditDetail,
          'SecurityQuestionId' => $_POST['SecurityId'],
        );
        $auditTable = 'R_Logs';
        $this->maintenance_model->insertFunction($insertData, $auditTable);

      // Insert Employees
        $insertData = array
        (
          'EmployeeNumber' => $EmployeeNumber,
          'SecurityQuestionId' => $_POST['SecurityId'],
          'Answer' => $_POST['Answer'],
        );
        $auditTable = 'R_Employee';
        $this->maintenance_model->insertFunction($insertData, $auditTable);
      // notification
        $this->session->set_flashdata('alertTitle','Success!'); 
        $this->session->set_flashdata('alertText','Security question successfully set!'); 
        $this->session->set_flashdata('alertType','success'); 
      
      redirect('home/userprofile');
    }
  }

  function addUser()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $DateNow = date("Y-m-d H:i:s");
    if($this->uri->segment(3) == 1) // update Security Question
    {
      // audits
        $auditDetail = 'Changed temporary password.';
        $insertData = array(
          'Description' => $auditDetail,
          'CreatedBy' => $EmployeeNumber
        );
        $auditTable = 'R_Logs';
        $this->maintenance_model->insertFunction($insertData, $auditTable);
      // Update Security Question
        $set = array( 
          'StatusId' => 0
        );

        $condition = array( 
          'EmployeeNumber' => $EmployeeNumber
        );
        $table = 'R_userrole_has_r_securityquestions';
        $this->maintenance_model->updateFunction1($set, $condition, $table);
      // insert user security question 1 
        $insertData2 = array
        (
          'SecurityQuestionId' => $_POST['Question1'],
          'EmployeeNumber' => $EmployeeNumber,
          'QuestionNumber' => 1,
          'Answer' => $_POST['Answer1'],
          'CreatedBy' => $EmployeeNumber
        );
        $auditTable2 = 'R_userrole_has_r_securityquestions';
        $this->maintenance_model->insertFunction($insertData2, $auditTable2);
      // insert user security question 2
        $insertData2 = array
        (
          'SecurityQuestionId' => $_POST['Question2'],
          'EmployeeNumber' => $EmployeeNumber,
          'QuestionNumber' => 2,
          'Answer' => $_POST['Answer2'],
          'CreatedBy' => $EmployeeNumber
        );
        $auditTable2 = 'R_userrole_has_r_securityquestions';
        $this->maintenance_model->insertFunction($insertData2, $auditTable2);
      // insert user security question 3
        $insertData2 = array
        (
          'SecurityQuestionId' => $_POST['Question3'],
          'EmployeeNumber' => $EmployeeNumber,
          'QuestionNumber' => 3,
          'Answer' => $_POST['Answer3'],
          'CreatedBy' => $EmployeeNumber
        );
        $auditTable2 = 'R_userrole_has_r_securityquestions';
        $this->maintenance_model->insertFunction($insertData2, $auditTable2);

      // update temporary password
        $set = array( 
          'Password'  => $_POST['NewPassword'],
          'IsNew'     => 0
        );

        $condition = array( 
          'EmployeeNumber' => $EmployeeNumber
        );
        $table = 'r_userrole';
        $this->maintenance_model->updateFunction1($set, $condition, $table);
      // notification
        $this->session->set_flashdata('alertTitle','Success!'); 
        $this->session->set_flashdata('alertText','Temporary password successfully changed!'); 
        $this->session->set_flashdata('alertType','success'); 
      
      redirect('home/userprofile/' . $EmployeeNumber);
    }
  }

  function ResetPassword()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $DateNow = date("Y-m-d H:i:s");
    // update password
      $set = array( 
        'Password' => $_POST['NewPassword'],
        'IsNew' => 0
      );

      $condition = array( 
        'EmployeeNumber' => $EmployeeNumber
      );
      $table = 'r_userrole';
      $this->maintenance_model->updateFunction1($set, $condition, $table);

    // audits
      $auditDetail = 'Changed password.';
      $insertData = array(
        'Description' => $auditDetail,
        'CreatedBy' => $EmployeeNumber
      );
      $auditTable = 'R_Logs';
      $this->maintenance_model->insertFunction($insertData, $auditTable);
    // notification
      $this->session->set_flashdata('alertTitle','Success!'); 
      $this->session->set_flashdata('alertText','Password successfully changed!'); 
      $this->session->set_flashdata('alertType','success'); 
    
    redirect('home/userprofile/' . $EmployeeNumber);
  }

}
