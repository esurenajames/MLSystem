<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class employee_controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('maintenance_model');
		$this->load->model('access');
		$this->load->model('employee_model');

   	if(empty($this->session->userdata("EmployeeNumber")) || $this->session->userdata("logged_in") == 0)
   	{
      $DateNow = date("Y-m-d H:i:s");
     	$this->session->set_flashdata('logout','Account successfully logged out.'); 
      $data = array(
      	'Description' => 'Session timed out.'
      	, 'DateCreated' => $DateNow
      	, 'CreatedBy' => $this->session->userdata('EmployeeNumber')
      );
      $this->access->audit($data);
      $loginSession = array(
        'logged_in' => 0,
      );
   		redirect(site_url());
   	}
	}

	function SecurityQuestion()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $DateNow = date("Y-m-d H:i:s");
    // audits
      $auditDetail = 'Security Question updated.';
      $insertData = array(
        'Description' => $auditDetail,
        'CreatedBy' => $EmployeeNumber
      );
      $auditTable = 'R_Logs';
      $this->maintenance_model->insertFunction($insertData, $auditTable);
    // Update Security Question
      $set = array( 
        'StatusId' => 0
      );

      $condition = array( 
        'EmployeeNumber' => $EmployeeNumber
      );
      $table = 'R_userrole_has_r_securityquestions';
      $this->maintenance_model->updateFunction1($set, $condition, $table);
    // insert user security question 1 
      $insertData2 = array
      (
        'SecurityQuestionId' => $_POST['Question1'],
        'EmployeeNumber' => $EmployeeNumber,
        'QuestionNumber' => 1,
        'Answer' => $_POST['Answer1'],
        'CreatedBy' => $EmployeeNumber
      );
      $auditTable2 = 'R_userrole_has_r_securityquestions';
      $this->maintenance_model->insertFunction($insertData2, $auditTable2);
    // insert user security question 2
      $insertData2 = array
      (
        'SecurityQuestionId' => $_POST['Question2'],
        'EmployeeNumber' => $EmployeeNumber,
        'QuestionNumber' => 2,
        'Answer' => $_POST['Answer2'],
        'CreatedBy' => $EmployeeNumber
      );
      $auditTable2 = 'R_userrole_has_r_securityquestions';
      $this->maintenance_model->insertFunction($insertData2, $auditTable2);
    // insert user security question 3
      $insertData2 = array
      (
        'SecurityQuestionId' => $_POST['Question3'],
        'EmployeeNumber' => $EmployeeNumber,
        'QuestionNumber' => 3,
        'Answer' => $_POST['Answer3'],
        'CreatedBy' => $EmployeeNumber
      );
      $auditTable2 = 'R_userrole_has_r_securityquestions';
      $this->maintenance_model->insertFunction($insertData2, $auditTable2);
    // notification
      $this->session->set_flashdata('alertTitle','Success!'); 
      $this->session->set_flashdata('alertText','Security question successfully set!'); 
      $this->session->set_flashdata('alertType','success'); 
    
    redirect('home/userprofile');
  }


 
	function Users()
	{
		$result = $this->maintenance_model->getAllUsers();
		foreach($result as $key=>$row)
		{
			$result[$key]['Name'] = $this->maintenance_model->getUserCreated($row['EmployeeNumber']);
		}
		echo json_encode($result);
	}

  function updateStatus()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $input = array( 
      'UserRoleId' => htmlentities($this->input->post('UserRoleId'), ENT_QUOTES)
      , 'updateType' => htmlentities($this->input->post('updateType'), ENT_QUOTES)
    );

    $query = $this->employee_model->updateStatus($input);
  }

  function updateContactNumber()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $input = array( 
      'Id' => htmlentities($this->input->post('EmployeeContactId'), ENT_QUOTES)
      , 'updateType' => htmlentities($this->input->post('updateType'), ENT_QUOTES)
    );

    $query = $this->employee_model->updateContactNumber($input);
  }

  function updateEmail()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $input = array( 
      'Id' => htmlentities($this->input->post('Id'), ENT_QUOTES)
      , 'updateType' => htmlentities($this->input->post('updateType'), ENT_QUOTES)
    );

    $query = $this->employee_model->updateEmail($input);
  }

  function employeeProcessing()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $DateNow = date("Y-m-d H:i:s");
    if($this->uri->segment(3) == 1) // add employee
    {
      $time = strtotime($_POST['DateOfBirth']);
      $newformat = date('Y-m-d', $time);
      $time2 = strtotime($_POST['DateHired']);
      $dateHired = date('Y-m-d', $time2);
      $EmpDateHired = date('mdy', $time2);

      $data = array(
        'FirstName'                     => htmlentities($_POST['FirstName'], ENT_QUOTES)
        , 'MiddleName'                  => htmlentities($_POST['MiddleName'], ENT_QUOTES)
        , 'LastName'                    => htmlentities($_POST['LastName'], ENT_QUOTES)
        , 'ExtName'                     => htmlentities($_POST['ExtName'], ENT_QUOTES)
        , 'DateOfBirth'                 => htmlentities($newformat, ENT_QUOTES)
        , 'DateHired'                   => htmlentities($dateHired, ENT_QUOTES)
        , 'CreatedBy'                   => $EmployeeNumber
        , 'UpdatedBy'                   => $EmployeeNumber
      );
      $query = $this->employee_model->countEmployee($data);
      if($query == 0) // not existing
      {
        // insert employee details
          $insertEmployee = array(
            'Salutation'                    => htmlentities($_POST['SalutationId'], ENT_QUOTES)
            , 'FirstName'                   => htmlentities($_POST['FirstName'], ENT_QUOTES)
            , 'MiddleName'                  => htmlentities($_POST['MiddleName'], ENT_QUOTES)
            , 'LastName'                    => htmlentities($_POST['LastName'], ENT_QUOTES)
            , 'ExtName'                     => htmlentities($_POST['ExtName'], ENT_QUOTES)
            , 'Sex'                         => htmlentities($_POST['SexId'], ENT_QUOTES)
            , 'Nationality'                 => htmlentities($_POST['NationalityId'], ENT_QUOTES)
            , 'CivilStatus'                 => htmlentities($_POST['CivilStatusId'], ENT_QUOTES)
            , 'DateOfBirth'                 => htmlentities($newformat, ENT_QUOTES)
            , 'DateHired'                   => htmlentities($dateHired, ENT_QUOTES)
            , 'PositionId'                  => htmlentities($_POST['PositionId'], ENT_QUOTES)
            , 'StatusId'                    => 2
            , 'CreatedBy'                   => $EmployeeNumber
            , 'UpdatedBy'                   => $EmployeeNumber
          );
          $insertEmployeeTable = 'R_Employee';
          $this->maintenance_model->insertFunction($insertEmployee, $insertEmployeeTable);
        // get employee generated id
          $auditData1 = array(
            'table'                 => 'R_Employee'
            , 'column'              => 'EmployeeId'
          );
          $EmployeeId = $this->maintenance_model->getGeneratedId($auditData1);

        // generate employee code number
          $branchCode = $this->maintenance_model->getBranchCode($_POST['BranchId']);
          $generatedEmployeeNumber = $number = str_pad($EmployeeId['EmployeeId'], 6, '0', STR_PAD_LEFT);
          $set = array( 
            'EmployeeNumber' => $generatedEmployeeNumber
          );

          $condition = array( 
            'EmployeeId' => $EmployeeId['EmployeeId']
          );
          $table = 'R_Employee';
          $this->maintenance_model->updateFunction1($set, $condition, $table);

        // insert into r_userrole
          foreach ($_POST['roleId'] as $value) 
          {
            $insertRoles = array(
              'EmployeeNumber'                    => $generatedEmployeeNumber
              , 'RoleId'                          => $value
              , 'Password'                        => $generatedEmployeeNumber
              , 'CreatedBy'                       => $EmployeeNumber
              , 'UpdatedBy'                       => $EmployeeNumber
            );
            $insertRoleTable = 'R_Userrole';
            $this->maintenance_model->insertFunction($insertRoles, $insertRoleTable);
          }

        // Insert Employee Type
          if($_POST['EmployeeType'] != 'Manager')
          {
            $insertEmployeeBranch = array(
              'EmployeeNumber'                => $set['EmployeeNumber']
              , 'BranchId'                    => htmlentities($_POST['BranchId'], ENT_QUOTES)
              , 'ManagerBranchId'             => htmlentities($_POST['ManagerId'], ENT_QUOTES)
              , 'CreatedBy'                   => $EmployeeNumber
              , 'UpdatedBy'                   => $EmployeeNumber
            );
            $insertEmployeeBranchTable = 'Branch_has_Employee';
            $this->maintenance_model->insertFunction($insertEmployeeBranch, $insertEmployeeBranchTable);
            // insert manager_has_notification
              $EmployeeName = htmlentities($_POST['LastName'], ENT_QUOTES) . ', ' . htmlentities($_POST['FirstName'], ENT_QUOTES) ;
              $insertNotification = array(
                'Description'                 => 'Added '.$EmployeeName.' with employee number ' . $generatedEmployeeNumber . ' to your branch. Please notify ' . $EmployeeName . ' that assigned password is assigned employee number.'
                , 'ManagerBranchId'             => htmlentities($_POST['ManagerId'], ENT_QUOTES)
                , 'CreatedBy'                   => $EmployeeNumber
              );
              $insertNotificationTable = 'manager_has_notifications';
              $this->maintenance_model->insertFunction($insertNotification, $insertNotificationTable);
          }
          else // Employee
          {
            $insertManager = array(
              'EmployeeNumber'                => $set['EmployeeNumber']
              , 'BranchId'                    => htmlentities($_POST['BranchId'], ENT_QUOTES)
              , 'CreatedBy'                   => $EmployeeNumber
              , 'UpdatedBy'                   => $EmployeeNumber
            );
            $insertManagerTable = 'Branch_has_Manager';
            $this->maintenance_model->insertFunction($insertManager, $insertManagerTable);
          }
        // insert mobile number
          // insert into contact numbers
            $insertContact1 = array(
              'PhoneType'                     => 'Mobile'
              , 'Number'                      => htmlentities($_POST['ContactNumber'], ENT_QUOTES)
              , 'CreatedBy'                   => $EmployeeNumber
            );
            $insertContactTable1 = 'r_contactnumbers';
            $this->maintenance_model->insertFunction($insertContact1, $insertContactTable1);
          // get mobile number id
            $generatedIdData1 = array(
              'table'                         => 'r_contactnumbers'
              , 'column'                      => 'ContactNumberId'
            );
            $mobileNumberId = $this->maintenance_model->getGeneratedId($generatedIdData1);
          // insert into employee contact numbers
            $insertContact2 = array(
              'EmployeeNumber'                => $generatedEmployeeNumber
              , 'ContactNumberId'             => $mobileNumberId['ContactNumberId']
              , 'CreatedBy'                   => $EmployeeNumber
              , 'UpdatedBy'                   => $EmployeeNumber
            );
            $insertContactTable2 = 'employee_has_contactnumbers';
            $this->maintenance_model->insertFunction($insertContact2, $insertContactTable2);

        // insert telephone number
          if(htmlentities($_POST['TelephoneNumber'], ENT_QUOTES) != '')
          {
            // insert into telephone numbers
              $insertTelephone1 = array(
                'PhoneType'                     => 'Telephone'
                , 'Number'                      => htmlentities($_POST['TelephoneNumber'], ENT_QUOTES)
                , 'CreatedBy'                   => $EmployeeNumber
              );
              $insertTelephoneTable1 = 'r_contactnumbers';
              $this->maintenance_model->insertFunction($insertTelephone1, $insertTelephoneTable1);
            // get mobile number id
              $generatedIdData2 = array(
                'table'                 => 'r_contactnumbers'
                , 'column'              => 'ContactNumberId'
              );
              $TelephoneNumberId = $this->maintenance_model->getGeneratedId($generatedIdData2);
            // insert into client contact numbers
              $insertTelephone2 = array(
                'EmployeeNumber'                => $generatedEmployeeNumber
                , 'ContactNumberId'             => $TelephoneNumberId['ContactNumberId']
                , 'CreatedBy'                   => $EmployeeNumber
                , 'UpdatedBy'                   => $EmployeeNumber
              );
              $insertTelephoneTable2 = 'employee_has_contactnumbers';
              $this->maintenance_model->insertFunction($insertTelephone2, $insertTelephoneTable2);
          }

        // insert email address
          // insert into email addresses
            $insertDataEmail = array(
              'EmailAddress'                  => htmlentities($_POST['EmailAddress'], ENT_QUOTES)
              , 'CreatedBy'                   => $EmployeeNumber
            );
            $insertTableEmail = 'r_emails';
            $this->maintenance_model->insertFunction($insertDataEmail, $insertTableEmail);
          // get email address id
            $generatedIdData3 = array(
              'table'                 => 'r_emails'
              , 'column'              => 'EmailId'
            );
            $EmailId = $this->maintenance_model->getGeneratedId($generatedIdData3);
          // insert into employee contact numbers
            $insertDataEmail2 = array(
              'EmployeeNumber'                      => $generatedEmployeeNumber
              , 'EmailId'                     => $EmailId['EmailId']
              , 'CreatedBy'                   => $EmployeeNumber
              , 'UpdatedBy'                   => $EmployeeNumber
            );
            $insertTableEmail2 = 'employee_has_emails';
            $this->maintenance_model->insertFunction($insertDataEmail2, $insertTableEmail2);

        // insert city address
          // insert into addresses
            $insertDataAddress = array(
              'HouseNo'                           => htmlentities($_POST['HouseNo'], ENT_QUOTES)
              , 'Street'                          => htmlentities($_POST['StreetNo'], ENT_QUOTES)
              , 'AddressType'                     => 'City Address'
              , 'BarangayId'                      => htmlentities($_POST['BarangayId'], ENT_QUOTES)
              , 'CreatedBy'                   => $EmployeeNumber
            );
            $insertTableAddress = 'r_address';
            $this->maintenance_model->insertFunction($insertDataAddress, $insertTableAddress);
          // get address id
            $generatedIdData4 = array(
              'table'                 => 'r_address'
              , 'column'              => 'AddressId'
            );
            $AddressId = $this->maintenance_model->getGeneratedId($generatedIdData4);
          // insert into Employee addresses
              $insertDataAddress2 = array(
                'EmployeeNumber'                    => $generatedEmployeeNumber
                , 'AddressId'                       => $AddressId['AddressId']
                , 'CreatedBy'                       => $EmployeeNumber
                , 'UpdatedBy'                       => $EmployeeNumber
              );
            $insertTableAddress2 = 'employee_has_address';
            $this->maintenance_model->insertFunction($insertDataAddress2, $insertTableAddress2);

        // insert province address
          if(htmlentities($_POST['IsSameAddress'], ENT_QUOTES) == 1)
          {
            // insert into addresses
              $insertDataAddress = array(
                'HouseNo'                           => htmlentities($_POST['HouseNo'], ENT_QUOTES)
                , 'Street'                          => htmlentities($_POST['StreetNo'], ENT_QUOTES)
                , 'AddressType'                     => 'Province Address'
                , 'BarangayId'                      => htmlentities($_POST['BarangayId'], ENT_QUOTES)
                , 'CreatedBy'                       => $EmployeeNumber
              );
              $insertTableAddress = 'r_address';
              $this->maintenance_model->insertFunction($insertDataAddress, $insertTableAddress);
            // get address id
              $generatedIdData4 = array(
                'table'                 => 'r_address'
                , 'column'              => 'AddressId'
              );
              $AddressId = $this->maintenance_model->getGeneratedId($generatedIdData4);
            // insert into employee addresses
              $insertDataAddress2 = array(
                'EmployeeNumber'                          => $generatedEmployeeNumber
                , 'AddressId'                       => $AddressId['AddressId']
                , 'CreatedBy'                       => $EmployeeNumber
                , 'UpdatedBy'                       => $EmployeeNumber
              );
              $insertTableAddress2 = 'employee_has_address';
              $this->maintenance_model->insertFunction($insertDataAddress2, $insertTableAddress2);
          }
          else
          {
            // insert into addresses
              $insertDataAddress = array(
                'HouseNo'                           => htmlentities($_POST['HouseNo2'], ENT_QUOTES)
                , 'Street'                          => htmlentities($_POST['StreetNo2'], ENT_QUOTES)
                , 'AddressType'                     => 'Province Address'
                , 'BarangayId'                      => htmlentities($_POST['BarangayId2'], ENT_QUOTES)
                , 'CreatedBy'                       => $EmployeeNumber
              );
              $insertTableAddress = 'r_address';
              $this->maintenance_model->insertFunction($insertDataAddress, $insertTableAddress);
            // get address id
              $generatedIdData4 = array(
                'table'                 => 'r_address'
                , 'column'              => 'AddressId'
              );
              $AddressId = $this->maintenance_model->getGeneratedId($generatedIdData4);
            // insert into employee addresses
                $insertDataAddress2 = array(
                  'EmployeeNumber'                          => $generatedEmployeeNumber
                  , 'AddressId'                       => $AddressId['AddressId']
                  , 'CreatedBy'                       => $EmployeeNumber
                  , 'UpdatedBy'                       => $EmployeeNumber
                );
              $insertTableAddress2 = 'employee_has_address';
              $this->maintenance_model->insertFunction($insertDataAddress2, $insertTableAddress2);
          }

        // admin audits
          $auditquery = $this->employee_model->getEmployeeDetail($EmployeeId['EmployeeId']);
          $auditDetail = 'Added '.$auditquery['Name'].' in employee list.';
          $insertData = array(
            'Description' => $auditDetail,
            'CreatedBy' => $EmployeeNumber,
            'DateCreated' => $DateNow
          );
          $this->maintenance_model->insertAdminLog($insertData);

        // employee audits
          $auditEmployee = 'Added in employee list.';
          $insertAuditEmployee = array(
            'Description' => $auditEmployee,
            'CreatedBy' => $EmployeeNumber,
            'DateCreated' => $DateNow
          );
          $auditTable = 'L_EmployeeLog';
          $this->maintenance_model->insertFunction($insertAuditEmployee, $auditTable);

        // notification
          $this->session->set_flashdata('alertTitle','Success!'); 
          $this->session->set_flashdata('alertText','Employee successfully recorded!'); 
          $this->session->set_flashdata('alertType','success'); 
          redirect('home/employeeDetails/'. $EmployeeId['EmployeeId']);
      }
      else
      {
        // notification
          $this->session->set_flashdata('alertTitle','Warning!'); 
          $this->session->set_flashdata('alertText','Employee already existing!'); 
          $this->session->set_flashdata('alertType','warning'); 
          redirect('home/addEmployees');
      }
    }
    else if($this->uri->segment(3) == 2) // add contact number 
    {
      $isPrimary = 0;
      if(isset($_POST['isPrimary']))
      {
        $isPrimary = 1;
        $set = array( 
          'IsPrimary' => 0
        );

        $condition = array( 
          'EmployeeNumber' => $this->uri->segment(4)
        );
        $table = 'employee_has_contactnumbers';
        $this->maintenance_model->updateFunction1($set, $condition, $table);
      }
      else
      {
        $isPrimary = 0;
      }
      $data = array(
        'PhoneType'                     => htmlentities($_POST['ContactType'], ENT_QUOTES)
        , 'Number'                      => htmlentities($_POST['FieldNumber'], ENT_QUOTES)
        , 'EmployeeNumber'              => $this->uri->segment(4)
      );
      $query = $this->employee_model->countContactNumber($data);
      if($query == 0)
      {
        if($_POST['ContactType'] == 'Mobile')
        {
          // insert into contact numbers
            $insertContact1 = array(
              'PhoneType'                     => 'Mobile'
              , 'Number'                      => htmlentities($_POST['FieldNumber'], ENT_QUOTES)
              , 'CreatedBy'                   => $EmployeeNumber
            );
            $insertContactTable1 = 'r_contactnumbers';
            $this->maintenance_model->insertFunction($insertContact1, $insertContactTable1);
          // get mobile number id
            $generatedIdData1 = array(
              'table'                         => 'r_contactnumbers'
              , 'column'                      => 'ContactNumberId'
            );
            $mobileNumberId = $this->maintenance_model->getGeneratedId($generatedIdData1);
          // insert into employee contact numbers
            $insertContact2 = array(
              'EmployeeNumber'                => $this->uri->segment(4)
              , 'ContactNumberId'             => $mobileNumberId['ContactNumberId']
              , 'IsPrimary'                   => $isPrimary
              , 'CreatedBy'                   => $EmployeeNumber
              , 'UpdatedBy'                   => $EmployeeNumber
            );
            $insertContactTable2 = 'employee_has_contactnumbers';
            $this->maintenance_model->insertFunction($insertContact2, $insertContactTable2);
        }
        else // telephone number
        {
          // insert into telephone numbers
            $insertTelephone1 = array(
              'PhoneType'                     => 'Telephone'
              , 'Number'                      => htmlentities($_POST['FieldNumber'], ENT_QUOTES)
              , 'CreatedBy'                   => $EmployeeNumber
            );
            $insertTelephoneTable1 = 'r_contactnumbers';
            $this->maintenance_model->insertFunction($insertTelephone1, $insertTelephoneTable1);
          // get mobile number id
            $generatedIdData2 = array(
              'table'                 => 'r_contactnumbers'
              , 'column'              => 'ContactNumberId'
            );
            $TelephoneNumberId = $this->maintenance_model->getGeneratedId($generatedIdData2);
          // insert into client contact numbers
            $insertTelephone2 = array(
              'EmployeeNumber'                => $this->uri->segment(4)
              , 'ContactNumberId'             => $TelephoneNumberId['ContactNumberId']
              , 'IsPrimary'                   => $isPrimary
              , 'CreatedBy'                   => $EmployeeNumber
              , 'UpdatedBy'                   => $EmployeeNumber
            );
            $insertTelephoneTable2 = 'employee_has_contactnumbers';
            $this->maintenance_model->insertFunction($insertTelephone2, $insertTelephoneTable2);
        }
        // notification
          $this->session->set_flashdata('alertTitle','Success!'); 
          $this->session->set_flashdata('alertText','Contact number successfully added!'); 
          $this->session->set_flashdata('alertType','success'); 
          redirect('home/employeeDetails/'. $_POST['EmployeeId']);
      }
      else
      {
        // notification
          $this->session->set_flashdata('alertTitle','Warning!'); 
          $this->session->set_flashdata('alertText','Contact number already existing!'); 
          $this->session->set_flashdata('alertType','warning'); 
          redirect('home/employeeDetails/'. $_POST['EmployeeId']);
      }
    }
    else if($this->uri->segment(3) == 3) // add email 
    {
      $isPrimary = 0;
      if(isset($_POST['isPrimary']))
      {
        $isPrimary = 1;
        $set = array( 
          'IsPrimary' => 0
        );

        $condition = array( 
          'EmployeeNumber' => $this->uri->segment(4)
        );
        $table = 'employee_has_emails';
        $this->maintenance_model->updateFunction1($set, $condition, $table);
      }
      else
      {
        $isPrimary = 0;
      }
      $data = array(
        'EmailAddress'                => htmlentities($_POST['EmailAddress'], ENT_QUOTES)
        , 'EmployeeNumber'              => $this->uri->segment(4)
      );
      $query = $this->employee_model->countEmailAddress($data);
      if($query == 0)
      {
        // insert into email
          $insertEmail1 = array(
            'EmailAddress'                      => htmlentities($_POST['EmailAddress'], ENT_QUOTES)
            , 'CreatedBy'                       => $EmployeeNumber
          );
          $insertEmailTable1 = 'r_emails';
          $this->maintenance_model->insertFunction($insertEmail1, $insertEmailTable1);
        // get email id
          $generatedIdData1 = array(
            'table'                         => 'r_emails'
            , 'column'                      => 'EmailId'
          );
          $generatedIdNumber = $this->maintenance_model->getGeneratedId($generatedIdData1);
        // insert into employee email
          $insertEmail2 = array(
            'EmployeeNumber'                => $this->uri->segment(4)
            , 'EmailId'                     => $generatedIdNumber['EmailId']
            , 'IsPrimary'                   => $isPrimary
            , 'CreatedBy'                   => $EmployeeNumber
            , 'UpdatedBy'                   => $EmployeeNumber
          );
          $insertEmailTable2 = 'employee_has_emails';
          $this->maintenance_model->insertFunction($insertEmail2, $insertEmailTable2);
        // notification
          $this->session->set_flashdata('alertTitle','Success!'); 
          $this->session->set_flashdata('alertText','Email address successfully added!'); 
          $this->session->set_flashdata('alertType','success'); 
          redirect('home/employeeDetails/'. $_POST['EmployeeId']);
      }
      else
      {
        // notification
          $this->session->set_flashdata('alertTitle','Warning!'); 
          $this->session->set_flashdata('alertText','Email address already existing!'); 
          $this->session->set_flashdata('alertType','warning'); 
          redirect('home/employeeDetails/'. $_POST['EmployeeId']);
      }
    }
    else if($this->uri->segment(3) == 4) // add address
    {
      $EmployeeNumber = $this->db->query("SELECT LPAD(".$this->uri->segment(4).", 6, 0) as EmployeeNumber")->row_array();
      $EmployeeDetail = $this->db->query("SELECT  EmployeeId
                                                  FROM R_Employee
                                                    WHERE EmployeeNumber = ".$EmployeeNumber['EmployeeNumber']."
      ")->row_array();
      $data = array(
        'HouseNo'                     => htmlentities($_POST['HouseNo'], ENT_QUOTES)
        , 'Street'                      => htmlentities($_POST['StreetNo'], ENT_QUOTES)
        , 'AddressType'                 => htmlentities($_POST['AddressType'], ENT_QUOTES)
        , 'BarangayId'                  => htmlentities($_POST['BarangayId'], ENT_QUOTES)
        , 'EmployeeNumber'              => $this->uri->segment(4)
      );
      $query = $this->employee_model->countAddress($data);
      if($query == 0)
      {
        // insert into address table
          $insertDataAddress = array(
            'HouseNo'                           => htmlentities($_POST['HouseNo'], ENT_QUOTES)
            , 'Street'                          => htmlentities($_POST['StreetNo'], ENT_QUOTES)
            , 'AddressType'                     => htmlentities($_POST['AddressType'], ENT_QUOTES)
            , 'BarangayId'                      => htmlentities($_POST['BarangayId'], ENT_QUOTES)
            , 'CreatedBy'                       => $EmployeeNumber['EmployeeNumber']
          );
          $insertTableAddress = 'r_address';
          $this->maintenance_model->insertFunction($insertDataAddress, $insertTableAddress);
        // get address id
          $generatedIdData = array(
            'table'                 => 'r_address'
            , 'column'              => 'AddressId'
          );
          $AddressId = $this->maintenance_model->getGeneratedId($generatedIdData);
        // Update existing primary address
          if($_POST['isPrimary'] == 1)
          {
            $set = array( 
              'isPrimary' => 0
            );

            $condition = array( 
              'EmployeeNumber' => $this->uri->segment(4)
              , 'isPrimary' => 1
            );
            $table = 'employee_has_address';
            $this->maintenance_model->updateFunction1($set, $condition, $table);
          }
        // insert into employee address      
          $insertDataAddress2 = array(
            'EmployeeNumber'                    => $this->uri->segment(4)
            , 'AddressId'                       => $AddressId['AddressId']
            , 'IsPrimary'                       => htmlentities($_POST['isPrimary'], ENT_QUOTES)
            , 'CreatedBy'                       => $EmployeeNumber['EmployeeNumber']
            , 'UpdatedBy'                       => $EmployeeNumber['EmployeeNumber']
          );
          $insertTableAddress2 = 'employee_has_address';
          $this->maintenance_model->insertFunction($insertDataAddress2, $insertTableAddress2);

        // insert into main logs
          $auditDetail = 'Added new address for employee #'. $EmployeeNumber['EmployeeNumber'];
          $insertData = array(
            'Description' => $auditDetail,
            'CreatedBy' => $EmployeeNumber['EmployeeNumber']
          );
          $auditTable = 'R_Logs';
          $this->maintenance_model->insertFunction($insertData, $auditTable);
        // insert into employee notification
          $auditDetail2 = 'Added new address.';
          $insertData2 = array(
            'Description' => $auditDetail2,
            'CreatedBy' => $EmployeeNumber['EmployeeNumber']
          );
          $auditTable2 = 'R_Logs';
          $this->maintenance_model->insertFunction($insertData2, $auditTable2);
        // notification
          $this->session->set_flashdata('alertTitle','Success!'); 
          $this->session->set_flashdata('alertText','Employee successfully recorded!'); 
          $this->session->set_flashdata('alertType','success'); 
          redirect('home/employeeDetails/'. $EmployeeDetail['EmployeeId']);
      }
      else
      {
        // notification
          $this->session->set_flashdata('alertTitle','Warning!'); 
          $this->session->set_flashdata('alertText','Address already existing!'); 
          $this->session->set_flashdata('alertType','warning'); 
          redirect('home/employeeDetails/'. $EmployeeDetail['EmployeeId']);
      }
    }
  }

  function getAllList()
  {
    $result = $this->employee_model->getAllList();
    foreach($result as $key=>$row)
    {
      $result[$key]['CreatedBy'] = $this->maintenance_model->getUserCreated($row['CreatedBy']);
    }
    echo json_encode($result);
  }

  function getCurrentPassword()
  {
    $output = $this->employee_model->getCurrentPassword(htmlentities($this->input->post('Password'), ENT_QUOTES), htmlentities($this->input->post('EmployeeNumber'), ENT_QUOTES));
    $this->output->set_output(print(json_encode($output)));
    exit();
  }

  function contactNumbers()
  {
    $Id = $this->uri->segment(3);
    $result = $this->employee_model->contactNumbers($Id);
    foreach($result as $key=>$row)
    {
      $result[$key]['Name'] = $this->maintenance_model->getUserCreated($row['CreatedBy']);
    }
    echo json_encode($result);
  }

  function employeeEmails()
  {
    $Id = $this->uri->segment(3);
    $result = $this->employee_model->employeeEmails($Id);
    foreach($result as $key=>$row)
    {
      $result[$key]['Name'] = $this->maintenance_model->getUserCreated($row['CreatedBy']);
    }
    echo json_encode($result);
  }

}
