<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class borrower_controller extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('maintenance_model');
		$this->load->model('access');
		$this->load->model('employee_model');
		$this->load->model('admin_model');
    $this->load->model('borrower_model');

   	if(empty($this->session->userdata("EmployeeNumber")) || $this->session->userdata("logged_in") == 0)
   	{
      $DateNow = date("Y-m-d H:i:s");
     	$this->session->set_flashdata('logout','Account successfully logged out.'); 
      $data = array(
      	'Description' => 'Session timed out.'
      	, 'DateCreated' => $DateNow
      	, 'CreatedBy' => $this->session->userdata('EmployeeNumber')
      );
      $this->access->audit($data);
      $loginSession = array(
        'logged_in' => 0,
      );
   		redirect(site_url());
   	}
	}

  function BorrowerProcessing()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $DateNow = date("Y-m-d H:i:s");
    if($this->uri->segment(3) == 1) // add client
    {
      $time = strtotime($_POST['DOB']);
      $newformat = date('Y-m-d', $time);

      $data = array(
        'FirstName'                     => htmlentities($_POST['FirstName'], ENT_QUOTES)
        , 'MiddleName'                  => htmlentities($_POST['MiddleName'], ENT_QUOTES)
        , 'LastName'                    => htmlentities($_POST['LastName'], ENT_QUOTES)
        , 'ExtName'                     => htmlentities($_POST['ExtName'], ENT_QUOTES)
        , 'DOB'                         => htmlentities($newformat, ENT_QUOTES)
        , 'CreatedBy'                   => $EmployeeNumber
        , 'UpdatedBy'                   => $EmployeeNumber
      );
      $query = $this->Borrower_model->countBorrower($data);
      if($query == 0) // not existing
      {
        // insert client details
          $insertBorrower = array(
            'Salutation'                    => htmlentities($_POST['SalutationId'], ENT_QUOTES)
            , 'FirstName'                   => htmlentities($_POST['FirstName'], ENT_QUOTES)
            , 'MiddleName'                  => htmlentities($_POST['MiddleName'], ENT_QUOTES)
            , 'LastName'                    => htmlentities($_POST['LastName'], ENT_QUOTES)
            , 'ExtName'                     => htmlentities($_POST['ExtName'], ENT_QUOTES)
            , 'Sex'                         => htmlentities($_POST['SexId'], ENT_QUOTES)
            , 'Nationality'                 => htmlentities($_POST['NationalityId'], ENT_QUOTES)
            , 'CivilStatus'                 => htmlentities($_POST['CivilStatusId'], ENT_QUOTES)
            , 'Dependents'                  => htmlentities($_POST['NoDependents'], ENT_QUOTES)
            , 'DateOfBirth'                 => htmlentities($newformat, ENT_QUOTES)
            , 'StatusId'                    => 2
            , 'CreatedBy'                   => $EmployeeNumber
            , 'UpdatedBy'                   => $EmployeeNumber
          );
          $insertBorrowerTable = 'R_Borrowers';
          $this->maintenance_model->insertFunction($insertBorrower, $insertBorrowerTable);
        // get client generated id
          $auditData1 = array(
            'table'                 => 'r_Borrowers'
            , 'column'              => 'BorrowerId'
          );
          $BorrowerId = $this->maintenance_model->getGeneratedId($auditData1);
          
        // insert mobile number
          // insert into contact numbers
            $insertContact1 = array(
              'PhoneType'                     => 'Mobile'
              , 'Number'                      => htmlentities($_POST['ContactNumber'], ENT_QUOTES)
              , 'CreatedBy'                      => $EmployeeNumber
            );
            $insertContactTable1 = 'r_contactnumbers';
            $this->maintenance_model->insertFunction($insertContact1, $insertContactTable1);
          // get mobile number id
            $generatedIdData1 = array(
              'table'                 => 'r_contactnumbers'
              , 'column'              => 'ContactNumberId'
            );
            $mobileNumberId = $this->maintenance_model->getGeneratedId($generatedIdData1);
          // insert into client contact numbers
            $insertContact2 = array(
              'BorrowerId'                     => $BorrowerId['BorrowerId']
              , 'ContactNumberId'              => $mobileNumberId['ContactNumberId']
              , 'CreatedBy'                   => $EmployeeNumber
              , 'UpdatedBy'                   => $EmployeeNumber
            );
            $insertContactTable2 = 'borrowers_has_contactnumbers';
            $this->maintenance_model->insertFunction($insertContact2, $insertContactTable2);

        // insert telephone number
          if(htmlentities($_POST['TelephoneNumber'], ENT_QUOTES) != '')
          {
            // insert into telephone numbers
              $insertTelephone1 = array(
                'PhoneType'                     => 'Telephone'
                , 'Number'                      => htmlentities($_POST['TelephoneNumber'], ENT_QUOTES)
                , 'CreatedBy'                   => $EmployeeNumber
              );
              $insertTelephoneTable1 = 'r_contactnumbers';
              $this->maintenance_model->insertFunction($insertTelephone1, $insertTelephoneTable1);
            // get mobile number id
              $generatedIdData2 = array(
                'table'                 => 'r_contactnumbers'
                , 'column'              => 'ContactNumberId'
              );
              $TelephoneNumberId = $this->maintenance_model->getGeneratedId($generatedIdData2);
            // insert into client contact numbers
              $insertTelephone2 = array(
                'BorrowerId'                     => $BorrowerId['BorrowerId']
                , 'ContactNumberId'              => $TelephoneNumberId['ContactNumberId']
                , 'CreatedBy'                   => $EmployeeNumber
                , 'UpdatedBy'                   => $EmployeeNumber
              );
              $insertTelephoneTable2 = 'borrowers_has_contactnumbers';
              $this->maintenance_model->insertFunction($insertTelephone2, $insertTelephoneTable2);
          }

        // insert email address
          // insert into email addresses
            $insertDataEmail = array(
              'EmailAddress'                  => htmlentities($_POST['EmailAddress'], ENT_QUOTES)
              , 'CreatedBy'                   => $EmployeeNumber
            );
            $insertTableEmail = 'r_emails';
            $this->maintenance_model->insertFunction($insertDataEmail, $insertTableEmail);
          // get mobile number id
            $generatedIdData3 = array(
              'table'                 => 'r_emails'
              , 'column'              => 'EmailId'
            );
            $EmailId = $this->maintenance_model->getGeneratedId($generatedIdData3);
          // insert into client contact numbers
            $insertDataEmail2 = array(
              'BorrowerId'                      => $BorrowerId['BorrowerId']
              , 'EmailId'                     => $EmailId['EmailId']
              , 'CreatedBy'                   => $EmployeeNumber
              , 'UpdatedBy'                   => $EmployeeNumber
            );
            $insertTableEmail2 = 'clients_has_emails';
            $this->maintenance_model->insertFunction($insertDataEmail2, $insertTableEmail2);

        // insert city address
          // insert into addresses
            $insertDataAddress = array(
              'HouseNo'                           => htmlentities($_POST['HouseNo'], ENT_QUOTES)
              , 'Street'                          => htmlentities($_POST['StreetNo'], ENT_QUOTES)
              , 'Telephone'                       => htmlentities($_POST['TelephoneCityAddress'], ENT_QUOTES)
              , 'ContactNumber'                   => htmlentities($_POST['CellphoneCityAdd'], ENT_QUOTES)
              , 'AddressType'                     => 'City Address'
              , 'BarangayId'                      => htmlentities($_POST['BarangayId'], ENT_QUOTES)
              , 'CreatedBy'                   => $EmployeeNumber
            );
            $insertTableAddress = 'r_address';
            $this->maintenance_model->insertFunction($insertDataAddress, $insertTableAddress);
          // get address id
            $generatedIdData4 = array(
              'table'                 => 'r_address'
              , 'column'              => 'AddressId'
            );
            $AddressId = $this->maintenance_model->getGeneratedId($generatedIdData4);
          // insert into client addresses
            if(htmlentities($_POST['optionsRadios'], ENT_QUOTES) == 'Rented')
            {
              $insertDataAddress2 = array(
                'BorrowerId'                          => $BorrowerId['BorrowerId']
                , 'AddressId'                       => $AddressId['AddressId']
                , 'YearsStayed'                     => htmlentities($_POST['YearsStayed'], ENT_QUOTES)
                , 'MonthsStayed'                    => htmlentities($_POST['MonthsStayed'], ENT_QUOTES)
                , 'AddressType'                     => htmlentities($_POST['optionsRadios'], ENT_QUOTES)
                , 'NameOfLandlord'                  => htmlentities($_POST['LandLord'], ENT_QUOTES)
                , 'ContactNumber'                   => htmlentities($_POST['LandLordNumber'], ENT_QUOTES)
                , 'CreatedBy'                       => $EmployeeNumber
                , 'UpdatedBy'                       => $EmployeeNumber
              );
            }
            else
            {
              $insertDataAddress2 = array(
                'BorrowerId'                          => $BorrowerId['BorrowerId']
                , 'AddressId'                       => $AddressId['AddressId']
                , 'AddressType'                     => 'City Address'
                , 'YearsStayed'                     => htmlentities($_POST['YearsStayed'], ENT_QUOTES)
                , 'MonthsStayed'                    => htmlentities($_POST['MonthsStayed'], ENT_QUOTES)
                , 'AddressType'                     => htmlentities($_POST['optionsRadios'], ENT_QUOTES)
                , 'CreatedBy'                       => $EmployeeNumber
                , 'UpdatedBy'                       => $EmployeeNumber
              );
            }
            $insertTableAddress2 = 'borroweraddresshistory';
            $this->maintenance_model->insertFunction($insertDataAddress2, $insertTableAddress2);

        // insert province address
          if(htmlentities($_POST['IsSameAddress'], ENT_QUOTES) == 1)
          {
            // insert into addresses
              $insertDataAddress = array(
                'HouseNo'                           => htmlentities($_POST['HouseNo'], ENT_QUOTES)
                , 'Street'                          => htmlentities($_POST['StreetNo'], ENT_QUOTES)
                , 'AddressType'                     => 'Province Address'
                , 'BarangayId'                      => htmlentities($_POST['BarangayId'], ENT_QUOTES)
                , 'CreatedBy'                       => $EmployeeNumber
              );
              $insertTableAddress = 'r_address';
              $this->maintenance_model->insertFunction($insertDataAddress, $insertTableAddress);
            // get address id
              $generatedIdData4 = array(
                'table'                 => 'r_address'
                , 'column'              => 'AddressId'
              );
              $AddressId = $this->maintenance_model->getGeneratedId($generatedIdData4);
            // insert into client addresses
              $insertDataAddress2 = array(
                'BorrowerId'                          => $BorrowerId['BorrowerId']
                , 'AddressId'                       => $AddressId['AddressId']
                , 'CreatedBy'                       => $EmployeeNumber
                , 'UpdatedBy'                       => $EmployeeNumber
              );
              $insertTableAddress2 = 'borroweraddresshistory';
              $this->maintenance_model->insertFunction($insertDataAddress2, $insertTableAddress2);
          }
          else
          {
            // insert into addresses
              $insertDataAddress = array(
                'HouseNo'                           => htmlentities($_POST['HouseNo2'], ENT_QUOTES)
                , 'Street'                          => htmlentities($_POST['StreetNo2'], ENT_QUOTES)
                , 'AddressType'                     => 'Province Address'
                , 'BarangayId'                      => htmlentities($_POST['BarangayId2'], ENT_QUOTES)
                , 'CreatedBy'                       => $EmployeeNumber
              );
              $insertTableAddress = 'r_address';
              $this->maintenance_model->insertFunction($insertDataAddress, $insertTableAddress);
            // get address id
              $generatedIdData4 = array(
                'table'                 => 'r_address'
                , 'column'              => 'AddressId'
              );
              $AddressId = $this->maintenance_model->getGeneratedId($generatedIdData4);
            // insert into client addresses
                $insertDataAddress2 = array(
                  'BorrowerId'                          => $BorrowerId['BorrowerId']
                  , 'AddressId'                       => $AddressId['AddressId']
                  , 'CreatedBy'                       => $EmployeeNumber
                  , 'UpdatedBy'                       => $EmployeeNumber
                );
              $insertTableAddress2 = 'clientaddresshistory';
              $this->maintenance_model->insertFunction($insertDataAddress2, $insertTableAddress2);
          }

        // admin audits
          $auditquery = $this->Borrower_model->getBorrowerDetail($BorrowerId['BorrowerId']);
          $auditDetail = 'Added '.$auditquery['Name'].' in borrower list.';
          $insertData = array(
            'Description' => $auditDetail,
            'CreatedBy' => $EmployeeNumber,
            'DateCreated' => $DateNow
          );
          $this->maintenance_model->insertAdminLog($insertData);

        // client audits
          $auditBorrower = 'Added in Borrowers list.';
          $insertAuditBorrower = array(
            'Description' => $auditBorrower,
            'CreatedBy' => $EmployeeNumber,
            'DateCreated' => $DateNow
          );
          $auditTable = 'L_BorrowerLog';
          $this->maintenance_model->insertFunction($insertAuditBorrower, $auditTable);

        // notification
          $this->session->set_flashdata('alertTitle','Success!'); 
          $this->session->set_flashdata('alertText','Borrower successfully recorded!'); 
          $this->session->set_flashdata('alertType','success'); 
          redirect('home/borrowerDetails/' . $BorrowerId['BorrowerId']);
      }
      else
      {
        // notification
          $this->session->set_flashdata('alertTitle','Warning!'); 
          $this->session->set_flashdata('alertText','Borrower already existing!'); 
          $this->session->set_flashdata('alertType','warning'); 
          redirect('home/borrowers');
      }
    }
    else if($this->uri->segment(3) == 2) // edit client
    {
      // notification
        $this->session->set_flashdata('alertTitle','Success!'); 
        $this->session->set_flashdata('alertText','Borrower successfully recorded!'); 
        $this->session->set_flashdata('alertType','success'); 
        redirect('home/borrowers');
    }
  }

  function AddContact()
  {
    $EmployeeNumber = $this->session->userdata('EmployeeNumber');
    $DateNow = date("Y-m-d H:i:s");
    if($_POST['FormType'] == 1) // add contact
    {
      if($_POST['ContactType'] == 'Mobile') //Mobile Number
      {
        // pass mo yung data to be used
        $data = array(
          'Type'                 => $_POST['']
          , 'Number'              => $_POST['ContactNumber']
          , 'BorrowerId'              => $_POST['']
        );
        $result = $this->borrower_model->countBorrower($data);
        if($result == 0)
        {
          // contact number
            $insertContact = array(
              'PhoneType'                     => 'Mobile'
              , 'Number'                      => htmlentities($_POST['ContactNumber'], ENT_QUOTES)
              , 'CreatedBy'                      => $EmployeeNumber
            );
            $insertContactTable = 'r_contactnumbers';
            $this->maintenance_model->insertFunction($insertContact, $insertContactTable);
          // get generated contactnumber id
            $generatedIdData = array(
              'table'                 => 'r_contactnumbers'
              , 'column'              => 'ContactNumberId'
            );
            $ContactNumberId = $this->maintenance_model->getGeneratedId($generatedIdData);
          // insert into borrower_has_contact
              $insertContact2 = array(
              'BorrowerId'                      => $_POST['ContactNumber']
                , 'ContactNumberId'             => $ContactNumberId['ContactNumberId']
                , 'CreatedBy'                   => $EmployeeNumber
                , 'UpdatedBy'                   => $EmployeeNumber
            );
            $insertContactTable2 = 'borrowers_has_contactnumbers';
            $this->maintenance_model->insertFunction($insertContact2, $insertContactTable2);
          // notification
            $this->session->set_flashdata('alertTitle','Success!'); 
            $this->session->set_flashdata('alertText','Contact number successfully added!'); 
            $this->session->set_flashdata('alertType','success'); 
            redirect('home/borrowerDetails/' . $BorrowerId['BorrowerId']);
        }
        else
        {
          // notification
            $this->session->set_flashdata('alertTitle','Warning!'); 
            $this->session->set_flashdata('alertText','Contact number already existing!'); 
            $this->session->set_flashdata('alertType','warning'); 
            redirect('home/borrowers');
        }
      }
      else // Telephone Number
      {
        $insertMobile = array(
          'PhoneType'                     => 'Telephone'
          , 'Number'                      => htmlentities($_POST['ContactNumber'], ENT_QUOTES)
          , 'CreatedBy'                      => $EmployeeNumber
        );
        $insertManagerTable = 'borrowers_has_contactnumbers';
        $this->maintenance_model->insertFunction($insertManager, $insertManagerTable);
      }


    }
    else if($_POST['FormType'] == 2) // edit contact
    {
      // input here the update function

      // notification
        $this->session->set_flashdata('alertTitle','Success!'); 
        $this->session->set_flashdata('alertText','Contact number successfully updated!'); 
        $this->session->set_flashdata('alertType','success'); 
        redirect('home/borrowers');
    }
  }

  

  function getAllList()
  {
    $result = $this->borrower_model->getAllList();
    foreach($result as $key=>$row)
    {
      $result[$key]['TotalLoans'] = $this->borrower_model->getTotalLoans($row['BorrowerId']);
    }
    echo json_encode($result);
  }

}
