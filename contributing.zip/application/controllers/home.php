<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();		
		$this->load->model('maintenance_model');
		$this->load->model('access');

   	if(empty($this->session->userdata("EmployeeNumber")) || $this->session->userdata("logged_in") == 0)
   	{
      $DateNow = date("Y-m-d H:i:s");
     	$this->session->set_flashdata('logout','Account successfully logged out.'); 
      $data = array(
      	'Description' => 'Session timed out.'
      	, 'DateCreated' => $DateNow
      	, 'CreatedBy' => $this->session->userdata('EmployeeNumber')
      );
      $this->access->audit($data);
      $loginSession = array(
        'logged_in' => 0,
      );
   		redirect(site_url());
   	}
	}

	function Dashboard()
	{
		$sidebar['sidebar'] = 1;
		$sidebar['sidebarMenu'] = 0;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();
		$data['access'] = $this->sidebar_model->getAccess();
		$data['securityQuestions'] = $this->employee_model->getSecurityQuestions();
		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('admin/dashboard', $data);
	}
	
	function Banks()
	{
		$sidebar['sidebar'] = 1;
		$sidebar['sidebarMenu'] = 0;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();
		$data['access'] = $this->sidebar_model->getAccess();
		$data['securityQuestions'] = $this->employee_model->getSecurityQuestions();
		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('admin/AddBanks', $data);
	}

	function employeeDetails()
	{
		$Id = $this->uri->segment(3);
		$sidebar['sidebar'] = 2;
		$sidebar['sidebarMenu'] = 3;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();
		$data['detail'] = $this->employee_model->getEmployeeDetails($Id);
		$data['branchDetail'] = $this->employee_model->getEmployeeBranchDetails($Id);
		$data['branchManager'] = $this->employee_model->getBranchManagerDetails($Id);

		$data['Address'] = $this->employee_model->getAddress($Id);

		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('admin/employeeDetails', $data);
	}

	function DashboardM()
	{
		$sidebar['sidebar'] = 1;
		$sidebar['sidebarMenu'] = 0;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();
		$data['access'] = $this->sidebar_model->getAccess();
		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('manager/dashboard', $data);
	}
	
	
	function NewBorrower()
	{
		$this->load->view('includes/header');
		$this->load->view('includes/sidebar');
		$this->load->view('borrower/NewCustomer');
	}
	
	function adminAuditLogs()
	{
		$sidebar['sidebar'] = 4;
		$sidebar['sidebarMenu'] = 2;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();
		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('admin/auditLogs');
	}
	
	function LoanCalculator()
	{
		$sidebar['sidebar'] = 3;
		$sidebar['sidebarMenu'] = 1;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();

		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('transaction/loanCalculator');
	}
	
	function addUser()
	{
		$sidebar['sidebar'] = 2;
		$sidebar['sidebarMenu'] = 3;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();

		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('admin/addUser');
	}

	function addEmployees()
	{
		$sidebar['sidebar'] = 2;
		$sidebar['sidebarMenu'] = 1;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();
		$data['Sex'] = $this->maintenance_model->getSex();
		$data['Nationality'] = $this->maintenance_model->getNationality();
		$data['CivilStatus'] = $this->maintenance_model->getCivilStatus();
		$data['Salutation'] = $this->maintenance_model->getSalutation();
		$data['Branch'] = $this->maintenance_model->getBranches();
		$data['Position'] = $this->maintenance_model->getPosition();
		$data['Roles'] = $this->maintenance_model->getRoles();

		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('admin/addEmployees', $data);
	}
	
	function userProfile()
	{
		$Id = $this->uri->segment(3);
		$sidebar['sidebar'] = 0;
		$sidebar['sidebarMenu'] = 0;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();
		$data['securityQuestions'] = $this->employee_model->getSecurityQuestions();
		$data['detail'] = $this->employee_model->getEmployeeProfile($Id);
		$data['branchDetail'] = $this->employee_model->getEmployeeProfileBranchDetails($Id);

		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('admin/userProfile', $data);
	}
	
	function borrowers()
	{
		$sidebar['sidebar'] = 2;
		$sidebar['sidebarMenu'] = 1;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();
		$data['Sex'] = $this->maintenance_model->getSex();
		$data['Nationality'] = $this->maintenance_model->getNationality();
		$data['CivilStatus'] = $this->maintenance_model->getCivilStatus();
		$data['Salutation'] = $this->maintenance_model->getSalutation();

		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('borrowers/dashboard', $data);
	}
	
	function BorrowerDetails()
	{
		$Id = $this->uri->segment(3);
		$sidebar['sidebar'] = 2;
		$sidebar['sidebarMenu'] = 1;
		$sidebar['access'] = $this->sidebar_model->checkSideBar();
		$data['Sex'] = $this->maintenance_model->getSex();
		$data['detail'] = $this->borrower_model->getBorrowerDetails($Id);
		$data['Nationality'] = $this->maintenance_model->getNationality();
		$data['CivilStatus'] = $this->maintenance_model->getCivilStatus();
		$data['Salutation'] = $this->maintenance_model->getSalutation();

		$this->load->view('includes/header');
		$this->load->view('includes/sidebar', $sidebar);
		$this->load->view('borrowers/BorrowerDetails', $data);
	}

}
